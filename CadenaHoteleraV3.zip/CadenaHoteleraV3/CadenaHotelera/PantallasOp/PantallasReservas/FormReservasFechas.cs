﻿using Cassandra;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    public partial class FormReservasFechas : Form
    {
        public FormReservasFechas()
        {
            InitializeComponent();
        }

        private void btn_verDisponibilidad_Click(object sender, EventArgs e)
        {
            dgv_ocupacion.Rows.Clear();

                        var session = CassandraConnector.Session;
            string hotel = ReservaTemp.HotelSeleccionado;

            var fechaInicio = dtp_entrada.Value.Date;
            var fechaFin = dtp_salida.Value.Date;

            // Obtener habitaciones ocupadas por reservaciones existentes
            string query = "SELECT * FROM  reservaciones WHERE nombre_hotel = ? ALLOW FILTERING";
            var result = session.Execute(session.Prepare(query).Bind(hotel));

            HashSet<string> ocupadas = new HashSet<string>();

            foreach (var row in result)
            {
                var fechaEntradaLocal = row.GetValue<Cassandra.LocalDate>("fecha_entrada");
                var fechaSalidaLocal = row.GetValue<Cassandra.LocalDate>("fecha_salida");

                DateTime fInicio = new DateTime(fechaEntradaLocal.Year, fechaEntradaLocal.Month, fechaEntradaLocal.Day);
                DateTime fFin = new DateTime(fechaSalidaLocal.Year, fechaSalidaLocal.Month, fechaSalidaLocal.Day);

                bool traslape = fInicio < fechaFin && fFin > fechaInicio;
                if (traslape)
                {
                    string tipo = row.GetValue<string>("tipo_cuarto");
                    ocupadas.Add(tipo);
                }
            }

            // Mostrar resultado
            foreach (var hab in ReservaTemp.Habitaciones)
            {
                string estado = ocupadas.Contains(hab.Tipo) ? "Ocupado" : "Disponible";
                dgv_ocupacion.Rows.Add(hab.Tipo, estado);
            }
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            
                if (dtp_entrada.Value >= dtp_salida.Value)
                {
                    MessageBox.Show("La fecha de salida debe ser después de la entrada.");
                    return;
                }

                ReservaTemp.FechaEntrada = dtp_entrada.Value.Date;
                ReservaTemp.FechaSalida = dtp_salida.Value.Date;

                MessageBox.Show("Fechas guardadas correctamente.");
                this.Close();
        }
        
    }
}
