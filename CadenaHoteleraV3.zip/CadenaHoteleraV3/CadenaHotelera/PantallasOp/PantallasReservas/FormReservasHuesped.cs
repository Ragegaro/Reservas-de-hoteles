﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    public partial class FormReservasHuesped : Form
    {
        public FormReservasHuesped()
        {
            InitializeComponent();
        }

        private void btn_seleccionar_Click(object sender, EventArgs e)
        {
            if (dgv_resultado.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un huésped.");
                return;
            }

            ReservaTemp.RfcHuesped = dgv_resultado.SelectedRows[0].Cells[0].Value.ToString();
            ReservaTemp.NombreCompleto = dgv_resultado.SelectedRows[0].Cells[1].Value.ToString() + " " +
                                         dgv_resultado.SelectedRows[0].Cells[2].Value.ToString() + " " +
                                         dgv_resultado.SelectedRows[0].Cells[3].Value.ToString();

            MessageBox.Show("Huésped seleccionado correctamente.");
            //this.Close(); // o pasar a la siguiente subpantalla
        }

        private void dgv_resultado_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Tomar el RFC de la fila seleccionada
                string rfcSeleccionado = dgv_resultado.Rows[e.RowIndex].Cells[0].Value.ToString();

                // Preparar la consulta a Cassandra
                var session = CassandraConnector.Session; // <-- Usas tu session ya creada

                string query = "SELECT * FROM huespedes WHERE rfc = ?";
                var prepared = session.Prepare(query);
                var statement = prepared.Bind(rfcSeleccionado);
                var row = session.Execute(statement).FirstOrDefault();

                if (row != null)
                {
                    // Cargar los datos en los TextBox
                    txt_rfc.Text = row.GetValue<string>("rfc");
                    txt_nombre.Text = row.GetValue<string>("nombres");
                    txt_apPat.Text = row.GetValue<string>("apellido_paterno");
                    txt_apMat.Text = row.GetValue<string>("apellido_materno");
                    txt_email.Text = row.GetValue<string>("email");
                    txt_telCasa.Text = row.GetValue<string>("telefono_casa");
                    txt_telCel.Text = row.GetValue<string>("telefono_celular");

                    // Si quieres también puedes cargar otros campos:
                    // txt_pais.Text = row.GetValue<string>("pais");
                    // txt_estado.Text = row.GetValue<string>("estado");
                    // txt_ciudad.Text = row.GetValue<string>("ciudad");
                    // txt_estadoCivil.Text = row.GetValue<string>("estado_civil");
                    // txt_fechaNac.Text = row.GetValue<LocalDate>("fecha_nacimiento").ToString();
                }
                else
                {
                    MessageBox.Show("No se encontró el huésped en la base de datos.");
                }
            }
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
                        var session = CassandraConnector.Session;
            string filtro = txt_busqueda.Text.ToLower();

            string query = "SELECT * FROM  huespedes ALLOW FILTERING";
            var resultado = session.Execute(query);

            if (dgv_resultado.Columns.Count == 0)
            {
                dgv_resultado.ColumnCount = 5;
                dgv_resultado.Columns[0].Name = "RFC";
                dgv_resultado.Columns[1].Name = "Nombres";
                dgv_resultado.Columns[2].Name = "Apellido Paterno";
                dgv_resultado.Columns[3].Name = "Apellido Materno";
                dgv_resultado.Columns[4].Name = "País";
            }

            dgv_resultado.Rows.Clear();

            foreach (var row in resultado)
            {
                string apPat = row.GetValue<string>("apellido_paterno").ToLower();
                string apMat = row.GetValue<string>("apellido_materno").ToLower();
                string rfc = row.GetValue<string>("rfc").ToLower();
                string email = row.GetValue<string>("email").ToLower();

                if (apPat.Contains(filtro) || apMat.Contains(filtro) || rfc.Contains(filtro) || email.Contains(filtro))
                {
                    dgv_resultado.Rows.Add(
                        row.GetValue<string>("rfc"),
                        row.GetValue<string>("nombres"),
                        row.GetValue<string>("apellido_paterno"),
                        row.GetValue<string>("apellido_materno"),
                        row.GetValue<string>("email")
                    );
                }
            }
        }
    }
}
