﻿using Cassandra;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp
{
    public partial class FormCheckin : Form
    {
        public FormCheckin()
        {
            InitializeComponent();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
                        var session = CassandraConnector.Session;

            if (!Guid.TryParse(txt_codigo.Text, out Guid codigo))
            {
                MessageBox.Show("Código inválido.");
                return;
            }

            string query = "SELECT * FROM  reservaciones WHERE codigo_reserva = ?";
            var prepared = session.Prepare(query);
            var result = session.Execute(prepared.Bind(codigo));

            var row = result.FirstOrDefault();
            if (row == null)
            {
                MessageBox.Show("Reservación no encontrada.");
                return;
            }

            dgv_reserva.Rows.Clear();
            dgv_reserva.ColumnCount = 7;
            dgv_reserva.Columns[0].Name = "Código";
            dgv_reserva.Columns[1].Name = "RFC";
            dgv_reserva.Columns[2].Name = "Hotel";
            dgv_reserva.Columns[3].Name = "Tipo de Habitación";
            dgv_reserva.Columns[4].Name = "Personas";
            dgv_reserva.Columns[5].Name = "Entrada";
            dgv_reserva.Columns[6].Name = "Salida";

            dgv_reserva.Rows.Add(
                row.GetValue<Guid>("codigo_reserva"),
                row.GetValue<string>("rfc_huesped"),
                row.GetValue<string>("nombre_hotel"),
                row.GetValue<string>("tipo_cuarto"),
                row.GetValue<int>("cantidad_personas"),
                new DateTime(
                    row.GetValue<Cassandra.LocalDate>("fecha_entrada").Year,
                    row.GetValue<Cassandra.LocalDate>("fecha_entrada").Month,
                    row.GetValue<Cassandra.LocalDate>("fecha_entrada").Day
                ).ToShortDateString(),
                new DateTime(
                    row.GetValue<Cassandra.LocalDate>("fecha_salida").Year,
                    row.GetValue<Cassandra.LocalDate>("fecha_salida").Month,
                    row.GetValue<Cassandra.LocalDate>("fecha_salida").Day
                ).ToShortDateString()
            );
        }
    }
}
