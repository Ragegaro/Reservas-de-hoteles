﻿namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    partial class FormReservasFechas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dtp_entrada = new DateTimePicker();
            dtp_salida = new DateTimePicker();
            dgv_ocupacion = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            btn_Confirmar = new Button();
            btn_verDisponibilidad = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_ocupacion).BeginInit();
            SuspendLayout();
            // 
            // dtp_entrada
            // 
            dtp_entrada.Location = new Point(177, 12);
            dtp_entrada.Name = "dtp_entrada";
            dtp_entrada.Size = new Size(200, 23);
            dtp_entrada.TabIndex = 0;
            // 
            // dtp_salida
            // 
            dtp_salida.Location = new Point(177, 41);
            dtp_salida.Name = "dtp_salida";
            dtp_salida.Size = new Size(200, 23);
            dtp_salida.TabIndex = 1;
            // 
            // dgv_ocupacion
            // 
            dgv_ocupacion.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_ocupacion.Location = new Point(12, 78);
            dgv_ocupacion.Name = "dgv_ocupacion";
            dgv_ocupacion.Size = new Size(1024, 436);
            dgv_ocupacion.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(12, 14);
            label1.Name = "label1";
            label1.Size = new Size(123, 21);
            label1.TabIndex = 57;
            label1.Text = "Fecha de entrada";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(12, 43);
            label2.Name = "label2";
            label2.Size = new Size(111, 21);
            label2.TabIndex = 58;
            label2.Text = "Fecha de salida";
            // 
            // btn_Confirmar
            // 
            btn_Confirmar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_Confirmar.Location = new Point(930, 35);
            btn_Confirmar.Name = "btn_Confirmar";
            btn_Confirmar.Size = new Size(106, 35);
            btn_Confirmar.TabIndex = 59;
            btn_Confirmar.Text = "Confirmar";
            btn_Confirmar.UseVisualStyleBackColor = true;
            btn_Confirmar.Click += btn_Confirmar_Click;
            // 
            // btn_verDisponibilidad
            // 
            btn_verDisponibilidad.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_verDisponibilidad.Location = new Point(393, 20);
            btn_verDisponibilidad.Name = "btn_verDisponibilidad";
            btn_verDisponibilidad.Size = new Size(106, 35);
            btn_verDisponibilidad.TabIndex = 60;
            btn_verDisponibilidad.Text = "Buscar";
            btn_verDisponibilidad.UseVisualStyleBackColor = true;
            btn_verDisponibilidad.Click += btn_verDisponibilidad_Click;
            // 
            // FormReservasFechas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 526);
            Controls.Add(btn_verDisponibilidad);
            Controls.Add(btn_Confirmar);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgv_ocupacion);
            Controls.Add(dtp_salida);
            Controls.Add(dtp_entrada);
            Name = "FormReservasFechas";
            Text = "fechas";
            ((System.ComponentModel.ISupportInitialize)dgv_ocupacion).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker dtp_entrada;
        private DateTimePicker dtp_salida;
        private DataGridView dgv_ocupacion;
        private Label label1;
        private Label label2;
        private Button btn_Confirmar;
        private Button btn_verDisponibilidad;
    }
}