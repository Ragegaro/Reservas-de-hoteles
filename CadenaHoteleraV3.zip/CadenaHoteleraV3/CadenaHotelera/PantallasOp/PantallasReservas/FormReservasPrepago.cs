﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    public partial class FormReservasPrepago : Form
    {
        public FormReservasPrepago()
        {
            InitializeComponent();
        }

        private void FormReservasPrepago_Load(object sender, EventArgs e)
        {
            decimal total = 0;
            dgv_resumen.Rows.Clear();

            foreach (var hab in ReservaTemp.Habitaciones)
            {
                decimal subtotal = hab.Cantidad * hab.PrecioUnitario;
                total += subtotal;

                dgv_resumen.Rows.Add(
                    hab.Tipo,
                    hab.Cantidad,
                    hab.Personas,
                    hab.PrecioUnitario.ToString("F2"),
                    subtotal.ToString("F2")
                );
            }

            txt_total.Text = total.ToString("F2");
        }

        private void tb_telCel_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_pagar_Click(object sender, EventArgs e)
        {
                        var session = CassandraConnector.Session;

            // Generar código de reserva único
            string codReserva = Guid.NewGuid().ToString().Substring(0, 8).ToUpper();

            foreach (var hab in ReservaTemp.Habitaciones)
            {
                var query = @"INSERT INTO  reservaciones (
            codigo_reserva, rfc_huesped, nombre_hotel, tipo_cuarto,
            cantidad, personas, fecha_entrada, fecha_salida,
            anticipo, total
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                var prepared = session.Prepare(query);
                var statement = prepared.Bind(
                    codReserva,
                    ReservaTemp.RfcHuesped,
                    ReservaTemp.HotelSeleccionado,
                    hab.Tipo,
                    hab.Cantidad,
                    hab.Personas,
                    ReservaTemp.FechaEntrada,
                    ReservaTemp.FechaSalida,
                    decimal.Parse(txt_anticipo.Text),
                    decimal.Parse(txt_total.Text)
                );

                session.Execute(statement);
            }

            lbl_codigo.Text = $"Código de Reserva: {codReserva}";
            MessageBox.Show("¡Reserva registrada correctamente!");
        }
    }
}
