﻿using Cassandra;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasAdm.Reportes
{
    public partial class FormHistorialCliente : Form
    {
        public FormHistorialCliente()
        {
            InitializeComponent();
        }
        private void FormHistorialCliente_Load(object sender, EventArgs e)
        {
            cmb_anio.Items.Clear();
            int anioActual = DateTime.Now.Year;
            cmb_anio.Items.Add("Todos");
            for (int i = anioActual; i >= anioActual - 10; i--)
                cmb_anio.Items.Add(i.ToString());
            cmb_anio.SelectedIndex = 0;
        }
        private void btn_buscar_Click(object sender, EventArgs e)
        {
            string email = txt_email.Text.Trim();
            if (string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Por favor, introduce un email.");
                return;
            }

            string anio = cmb_anio.SelectedItem.ToString();
            var session = CassandraConnector.Session;

            string query = "SELECT * FROM historial_cliente WHERE email = ? ALLOW FILTERING";

            var prepared = session.Prepare(query);
            var bound = prepared.Bind(email);

            var result = session.Execute(bound);


            if (dgv_historial.Columns.Count == 0)
            {
                dgv_historial.ColumnCount = 15;
                dgv_historial.Columns[0].Name = "Nombres";
                dgv_historial.Columns[1].Name = "Ciudad";
                dgv_historial.Columns[2].Name = "Hotel";
                dgv_historial.Columns[3].Name = "Tipo de Habitacioón";
                dgv_historial.Columns[4].Name = "Numero de Habitaición";
                dgv_historial.Columns[5].Name = "Personas";
                dgv_historial.Columns[6].Name = "Código";
                dgv_historial.Columns[7].Name = "Fecha Reserva";
                dgv_historial.Columns[8].Name = "Fecha Check-out";
                dgv_historial.Columns[9].Name = "Fecha Check-in";
                dgv_historial.Columns[10].Name = "Estatus";
                dgv_historial.Columns[11].Name = "Anticipo";
                dgv_historial.Columns[12].Name = "Monto hospedaje";
                dgv_historial.Columns[13].Name = "Monto Servicios";
                dgv_historial.Columns[14].Name = "Total";
            }

            dgv_historial.Rows.Clear();
            foreach (var row in result)
            {
                int anioReserva = row.GetValue<int>("anio");
                if (anio != "Todos" && anioReserva.ToString() != anio)
                    continue;

                var fechaReserva = row.GetValue<Cassandra.LocalDate>("fecha_reserva");
                var fechaCheckin = row.GetValue<Cassandra.LocalDate>("fecha_checkin");
                var fechaCheckout = row.GetValue<Cassandra.LocalDate>("fecha_checkout");

                dgv_historial.Rows.Add(
                    row.GetValue<string>("nombre_cliente"),
                    row.GetValue<string>("ciudad"),
                    row.GetValue<string>("nombre_hotel"),
                    row.GetValue<string>("tipo_habitacion"),
                    row.GetValue<int>("numero_habitacion"),
                    row.GetValue<int>("personas"),
                    row.GetValue<string>("codigo_reservacion"),
                    new DateTime(fechaReserva.Year, fechaReserva.Month, fechaReserva.Day).ToShortDateString(),
                    new DateTime(fechaCheckin.Year, fechaCheckin.Month, fechaCheckin.Day).ToShortDateString(),
                    new DateTime(fechaCheckout.Year, fechaCheckout.Month, fechaCheckout.Day).ToShortDateString(),
                    row.GetValue<string>("estatus"),
                    row.GetValue<decimal>("anticipo"),
                    row.GetValue<decimal>("monto_hospedaje"),
                    row.GetValue<decimal>("monto_servicios"),
                    row.GetValue<decimal>("total")
                );
            }
        }

        private void dgv_historial_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
