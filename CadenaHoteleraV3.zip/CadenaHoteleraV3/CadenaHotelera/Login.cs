﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace CadenaHotelera
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void FormLogin(object sender, EventArgs e)
        {
            radioButton1.Checked = true; // Marca el primer RadioButton por defecto
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                MenuAdm nuevaPantalla = new MenuAdm(); // Abre Form2 si el primer RadioButton está marcado
                nuevaPantalla.Show();
            }
            else if (radioButton2.Checked)
            {
                MenuOp otraPantalla = new MenuOp(); // Abre Form3 si el segundo RadioButton está marcado
                otraPantalla.Show();
            }

            this.Hide();
        }
    }
}
