﻿namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    partial class FormReservasHuesped
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_seleccionar = new Button();
            tb_buscarApe = new TextBox();
            btn_buscar = new Button();
            tb_buscarEmail = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            tb_buscarRFC = new TextBox();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            tb_telCel = new TextBox();
            tb_telCasa = new TextBox();
            tb_email = new TextBox();
            tb_rfc = new TextBox();
            tb_apMaterno = new TextBox();
            tb_apPaterno = new TextBox();
            tb_nombre = new TextBox();
            SuspendLayout();
            // 
            // btn_seleccionar
            // 
            btn_seleccionar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_seleccionar.Location = new Point(705, 397);
            btn_seleccionar.Name = "btn_seleccionar";
            btn_seleccionar.Size = new Size(168, 35);
            btn_seleccionar.TabIndex = 67;
            btn_seleccionar.Text = "Seleccionar";
            btn_seleccionar.UseVisualStyleBackColor = true;
            // 
            // tb_buscarApe
            // 
            tb_buscarApe.Location = new Point(82, 26);
            tb_buscarApe.Name = "tb_buscarApe";
            tb_buscarApe.Size = new Size(249, 23);
            tb_buscarApe.TabIndex = 66;
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_buscar.Location = new Point(347, 26);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(98, 35);
            btn_buscar.TabIndex = 65;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            // 
            // tb_buscarEmail
            // 
            tb_buscarEmail.Location = new Point(82, 86);
            tb_buscarEmail.Name = "tb_buscarEmail";
            tb_buscarEmail.Size = new Size(249, 23);
            tb_buscarEmail.TabIndex = 64;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(5, 28);
            label4.Name = "label4";
            label4.Size = new Size(75, 21);
            label4.TabIndex = 63;
            label4.Text = "Apellidos:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label5.Location = new Point(5, 88);
            label5.Name = "label5";
            label5.Size = new Size(59, 21);
            label5.TabIndex = 62;
            label5.Text = "E-mail:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label6.Location = new Point(5, 57);
            label6.Name = "label6";
            label6.Size = new Size(42, 21);
            label6.TabIndex = 61;
            label6.Text = "RFC:";
            // 
            // tb_buscarRFC
            // 
            tb_buscarRFC.Location = new Point(82, 57);
            tb_buscarRFC.Name = "tb_buscarRFC";
            tb_buscarRFC.Size = new Size(249, 23);
            tb_buscarRFC.TabIndex = 60;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(474, 318);
            label10.Name = "label10";
            label10.Size = new Size(120, 21);
            label10.TabIndex = 59;
            label10.Text = "Teléfono celular:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label9.Location = new Point(474, 276);
            label9.Name = "label9";
            label9.Size = new Size(123, 21);
            label9.TabIndex = 58;
            label9.Text = "Teléfono de casa:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(474, 234);
            label8.Name = "label8";
            label8.Size = new Size(59, 21);
            label8.TabIndex = 57;
            label8.Text = "E-mail:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(474, 192);
            label7.Name = "label7";
            label7.Size = new Size(42, 21);
            label7.TabIndex = 56;
            label7.Text = "RFC:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(74, 274);
            label3.Name = "label3";
            label3.Size = new Size(129, 21);
            label3.TabIndex = 55;
            label3.Text = "Apellido materno:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(74, 233);
            label2.Name = "label2";
            label2.Size = new Size(124, 21);
            label2.TabIndex = 54;
            label2.Text = "Apellido paterno:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(74, 192);
            label1.Name = "label1";
            label1.Size = new Size(88, 21);
            label1.TabIndex = 53;
            label1.Text = "Nombre(s):";
            // 
            // tb_telCel
            // 
            tb_telCel.Location = new Point(649, 320);
            tb_telCel.Name = "tb_telCel";
            tb_telCel.ReadOnly = true;
            tb_telCel.Size = new Size(119, 23);
            tb_telCel.TabIndex = 52;
            // 
            // tb_telCasa
            // 
            tb_telCasa.Location = new Point(649, 278);
            tb_telCasa.Name = "tb_telCasa";
            tb_telCasa.ReadOnly = true;
            tb_telCasa.Size = new Size(119, 23);
            tb_telCasa.TabIndex = 51;
            // 
            // tb_email
            // 
            tb_email.Location = new Point(649, 236);
            tb_email.Name = "tb_email";
            tb_email.ReadOnly = true;
            tb_email.Size = new Size(224, 23);
            tb_email.TabIndex = 50;
            // 
            // tb_rfc
            // 
            tb_rfc.Location = new Point(649, 194);
            tb_rfc.Name = "tb_rfc";
            tb_rfc.ReadOnly = true;
            tb_rfc.Size = new Size(224, 23);
            tb_rfc.TabIndex = 49;
            // 
            // tb_apMaterno
            // 
            tb_apMaterno.Location = new Point(221, 276);
            tb_apMaterno.Name = "tb_apMaterno";
            tb_apMaterno.ReadOnly = true;
            tb_apMaterno.Size = new Size(224, 23);
            tb_apMaterno.TabIndex = 48;
            // 
            // tb_apPaterno
            // 
            tb_apPaterno.Location = new Point(221, 235);
            tb_apPaterno.Name = "tb_apPaterno";
            tb_apPaterno.ReadOnly = true;
            tb_apPaterno.Size = new Size(224, 23);
            tb_apPaterno.TabIndex = 47;
            // 
            // tb_nombre
            // 
            tb_nombre.Location = new Point(221, 194);
            tb_nombre.Name = "tb_nombre";
            tb_nombre.ReadOnly = true;
            tb_nombre.Size = new Size(224, 23);
            tb_nombre.TabIndex = 46;
            // 
            // FormReservasHuesped
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 526);
            Controls.Add(btn_seleccionar);
            Controls.Add(tb_buscarApe);
            Controls.Add(btn_buscar);
            Controls.Add(tb_buscarEmail);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(tb_buscarRFC);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tb_telCel);
            Controls.Add(tb_telCasa);
            Controls.Add(tb_email);
            Controls.Add(tb_rfc);
            Controls.Add(tb_apMaterno);
            Controls.Add(tb_apPaterno);
            Controls.Add(tb_nombre);
            Name = "FormReservasHuesped";
            Text = "FormReservasHuesped";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_seleccionar;
        private TextBox tb_buscarApe;
        private Button btn_buscar;
        private TextBox tb_buscarEmail;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox tb_buscarRFC;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox tb_telCel;
        private TextBox tb_telCasa;
        private TextBox tb_email;
        private TextBox tb_rfc;
        private TextBox tb_apMaterno;
        private TextBox tb_apPaterno;
        private TextBox tb_nombre;
    }
}