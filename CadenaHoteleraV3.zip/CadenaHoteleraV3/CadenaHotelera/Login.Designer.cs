﻿namespace CadenaHotelera
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txt_email = new TextBox();
            txt_contra = new TextBox();
            btn_Login = new Button();
            SuspendLayout();
            // 
            // txt_email
            // 
            txt_email.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_email.Location = new Point(108, 196);
            txt_email.Name = "txt_email";
            txt_email.PlaceholderText = "E-Mail";
            txt_email.Size = new Size(159, 29);
            txt_email.TabIndex = 0;
            // 
            // txt_contra
            // 
            txt_contra.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_contra.Location = new Point(108, 266);
            txt_contra.Name = "txt_contra";
            txt_contra.PasswordChar = '*';
            txt_contra.PlaceholderText = "Contraseña";
            txt_contra.Size = new Size(159, 29);
            txt_contra.TabIndex = 1;
            txt_contra.UseSystemPasswordChar = true;
            // 
            // btn_Login
            // 
            btn_Login.BackColor = Color.CornflowerBlue;
            btn_Login.FlatStyle = FlatStyle.Flat;
            btn_Login.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_Login.Location = new Point(117, 342);
            btn_Login.Name = "btn_Login";
            btn_Login.Size = new Size(139, 35);
            btn_Login.TabIndex = 2;
            btn_Login.Text = "Iniciar de sesión";
            btn_Login.UseVisualStyleBackColor = false;
            btn_Login.Click += btn_Login_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(377, 496);
            Controls.Add(btn_Login);
            Controls.Add(txt_contra);
            Controls.Add(txt_email);
            Name = "Login";
            Text = "Inicio de sesión";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_email;
        private TextBox txt_contra;
        private Button btn_Login;
    }
}