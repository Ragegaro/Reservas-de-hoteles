﻿namespace CadenaHotelera.PantallasAdm
{
    partial class FormCancelaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_listaRes = new DataGridView();
            cb_codigoRes = new ComboBox();
            label8 = new Label();
            btn_cancelarRes = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_listaRes).BeginInit();
            SuspendLayout();
            // 
            // dgv_listaRes
            // 
            dgv_listaRes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_listaRes.Location = new Point(29, 78);
            dgv_listaRes.Name = "dgv_listaRes";
            dgv_listaRes.Size = new Size(1008, 502);
            dgv_listaRes.TabIndex = 0;
            // 
            // cb_codigoRes
            // 
            cb_codigoRes.FormattingEnabled = true;
            cb_codigoRes.Location = new Point(197, 42);
            cb_codigoRes.Name = "cb_codigoRes";
            cb_codigoRes.Size = new Size(279, 23);
            cb_codigoRes.TabIndex = 1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(29, 40);
            label8.Name = "label8";
            label8.Size = new Size(162, 21);
            label8.TabIndex = 44;
            label8.Text = " Código de reservación";
            // 
            // btn_cancelarRes
            // 
            btn_cancelarRes.Location = new Point(899, 49);
            btn_cancelarRes.Name = "btn_cancelarRes";
            btn_cancelarRes.Size = new Size(138, 23);
            btn_cancelarRes.TabIndex = 45;
            btn_cancelarRes.Text = "Cancelar reservación";
            btn_cancelarRes.UseVisualStyleBackColor = true;
            btn_cancelarRes.Click += btn_cancelarRes_Click;
            // 
            // FormCancelaciones
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(btn_cancelarRes);
            Controls.Add(label8);
            Controls.Add(cb_codigoRes);
            Controls.Add(dgv_listaRes);
            Name = "FormCancelaciones";
            Text = "FormCancelaciones";
            Load += FormCancelaciones_Load;
            ((System.ComponentModel.ISupportInitialize)dgv_listaRes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgv_listaRes;
        private ComboBox cb_codigoRes;
        private Label label8;
        private Button btn_cancelarRes;
    }
}