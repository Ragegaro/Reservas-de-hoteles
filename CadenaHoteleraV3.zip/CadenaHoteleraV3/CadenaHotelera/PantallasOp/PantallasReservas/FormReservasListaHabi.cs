﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    public partial class FormReservasListaHabi : Form
    {
        public FormReservasListaHabi()
        {
            InitializeComponent();
        }

        private void FormReservasListaHabi_Load(object sender, EventArgs e)
        {
            cb_tipoHabi.Items.Clear();
            lbx_listaHabi.Items.Clear();

                        var session = CassandraConnector.Session;
            var query = "SELECT * FROM  tipos_habitacion";
            var result = session.Execute(query);

            foreach (var row in result)
            {
                string nombre = row.GetValue<string>("nombre_tipo");
                cb_tipoHabi.Items.Add(nombre);
                lbx_listaHabi.Items.Add(nombre);
            }
        }

        private void listBoxHabitaciones_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbx_listaHabi.SelectedItem == null) return;

            string tipo = lbx_listaHabi.SelectedItem.ToString();
                        var session = CassandraConnector.Session;

            var query = "SELECT * FROM  tipos_habitacion WHERE nombre_tipo = ? ALLOW FILTERING";
            var prepared = session.Prepare(query);
            var row = session.Execute(prepared.Bind(tipo)).FirstOrDefault();

            if (row != null)
            {
                lab_nombre.Text = tipo;
                tb_desc1.Text = row.GetValue<string>("caracteristicas");
                tb_desc2.Text = row.GetValue<string>("amenidades");
                lb_presio.Text = row.GetValue<decimal>("presio").ToString("F2");
                //txt_disponibles.Text = row.GetValue<int>("cantidad_habitaciones").ToString();
            }
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {

        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {
            if (cb_tipoHabi.SelectedItem == null || tb_cantHabi.Text == "" || tb_cantHusped.Text == "")
            {
                MessageBox.Show("Completa todos los campos.");
                return;
            }

            string tipo = cb_tipoHabi.SelectedItem.ToString();
            int cantidad = int.Parse(tb_cantHabi.Text);
            int personas = int.Parse(tb_cantHusped.Text);
            decimal precio = decimal.Parse(lb_presio.Text);

            dgv_habiSeleccionadas.Rows.Add(tipo, cantidad, personas, precio);

            ReservaTemp.Habitaciones.Add(new HabitacionReservada
            {
                Tipo = tipo,
                Cantidad = cantidad,
                Personas = personas,
                PrecioUnitario = precio
            });
        }
    }
}
