﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NodaTime;

namespace CadenaHotelera.PantallasAdm
{
    public partial class FormRegUsuarios : Form
    {
        string rol = "operador";
        public FormRegUsuarios()
        {
            InitializeComponent();
            CargarUsuarios();
        }

        private void CargarUsuarios()
        {
            var session = CassandraConnector.Session;
            string query = "SELECT nombres, apellido_paterno, apellido_materno FROM usuarios";

            var result = session.Execute(query);

            if (dgv_clientes.Columns.Count == 0)
            {
                dgv_clientes.ColumnCount = 3;
                dgv_clientes.Columns[0].Name = "Nombres";
                dgv_clientes.Columns[1].Name = "Apellido Paterno";
                dgv_clientes.Columns[2].Name = "Apellido Materno";
            }

            dgv_clientes.Rows.Clear();

            foreach (var row in result)
            {
                dgv_clientes.Rows.Add(
                    row.GetValue<string>("nombres"),
                    row.GetValue<string>("apellido_paterno"),
                    row.GetValue<string>("apellido_materno")
                );
            }
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            string query = @"INSERT INTO  usuarios (
        email, contrasena, nombres, apellido_paterno, apellido_materno,
        nomina, fecha_nacimiento, telefono_casa, telefono_celular, fecha_registro, rol
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


            
            DateTime epoch = new DateTime(1970, 1, 1);
            int diasDesde1970 = (int)(dtp_nacimiento.Value.Date - epoch).TotalDays;

            var prepared = session.Prepare(query);  
            var statement = prepared.Bind(
                txt_email.Text,
                txt_contrasena.Text,
                txt_nombre.Text,
                txt_apPat.Text,
                txt_apMat.Text,
                txt_nomina.Text,
                diasDesde1970,
                txt_telCasa.Text,
                txt_telCel.Text,
                DateTime.Now,
                rol

            ) ;

            session.Execute(statement);
            CargarUsuarios();
            MessageBox.Show("Usuario registrado correctamente.");
        }
    }
}
