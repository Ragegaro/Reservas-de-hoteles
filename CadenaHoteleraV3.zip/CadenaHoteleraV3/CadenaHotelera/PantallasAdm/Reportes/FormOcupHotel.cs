﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasAdm.Reportes
{
    public partial class FormOcupHotel : Form
    {
        public FormOcupHotel()
        {
            InitializeComponent();
        }

        private void FormOcupHotel_Load(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            // Llenar País
            cmb_pais.Items.Clear();
            var queryPais = session.Prepare("SELECT DISTINCT pais FROM  ocupacion_hotel");
            var paises = session.Execute(queryPais.Bind());
            foreach (var row in paises)
                cmb_pais.Items.Add(row.GetValue<string>("pais"));

            // Llenar años
            cmb_anio.Items.Clear();
            int actual = DateTime.Now.Year;
            for (int i = actual; i >= actual - 10; i--)
                cmb_anio.Items.Add(i.ToString());
        }

        private void cmb_pais_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_ciudad.Items.Clear();
            string pais = cmb_pais.SelectedItem.ToString();
            var session = CassandraConnector.Session;

            var queryCiudad = session.Prepare("SELECT DISTINCT ciudad FROM  ocupacion_hotel WHERE pais = ?");
            var ciudades = session.Execute(queryCiudad.Bind(pais));

            foreach (var row in ciudades)
                cmb_ciudad.Items.Add(row.GetValue<string>("ciudad"));
        }

        private void cmb_ciudad_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_hotel.Items.Clear();
            string pais = cmb_pais.SelectedItem.ToString();
            string ciudad = cmb_ciudad.SelectedItem.ToString();
            var session = CassandraConnector.Session;

            var queryHotel = session.Prepare("SELECT DISTINCT nombre_hotel FROM  ocupacion_hotel WHERE pais = ? AND ciudad = ?");
            var hoteles = session.Execute(queryHotel.Bind(pais, ciudad));

            foreach (var row in hoteles)
                cmb_hotel.Items.Add(row.GetValue<string>("nombre_hotel"));
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            string pais = cmb_pais.Text;
            string ciudad = cmb_ciudad.Text;
            string hotel = cmb_hotel.Text;
            int anio = int.Parse(cmb_anio.Text);

            var session = CassandraConnector.Session;

            // Consulta principal
            var query1 = session.Prepare("SELECT * FROM  ocupacion_hotel WHERE pais = ? AND ciudad = ? AND nombre_hotel = ? AND anio = ?");
            var result1 = session.Execute(query1.Bind(pais, ciudad, hotel, anio));


            if (dgv_ocupacion.Columns.Count == 0)
            {
                dgv_ocupacion.ColumnCount = 8;
                dgv_ocupacion.Columns[0].Name = "Ciudad";
                dgv_ocupacion.Columns[1].Name = "Hotel";
                dgv_ocupacion.Columns[2].Name = "Año";
                dgv_ocupacion.Columns[3].Name = "Mes";
                dgv_ocupacion.Columns[4].Name = "Tipo de habitaición";
                dgv_ocupacion.Columns[5].Name = "Total de habitaciones";
                dgv_ocupacion.Columns[6].Name = "% de ocupación";
                dgv_ocupacion.Columns[7].Name = "Personas hospedadas";
            }

            dgv_ocupacion.Rows.Clear();
            foreach (var row in result1)
            {
                dgv_ocupacion.Rows.Add(
                    row.GetValue<string>("ciudad"),
                    row.GetValue<string>("nombre_hotel"),
                    row.GetValue<int>("anio"),
                    row.GetValue<string>("mes"),
                    row.GetValue<string>("tipo_habitacion"),
                    row.GetValue<int>("total_habitaciones"),
                    row.GetValue<decimal>("porcentaje_ocupacion"),
                    row.GetValue<int>("personas_hospedadas")
                );
            }

            // Consulta resumen
            var query2 = session.Prepare("SELECT * FROM  ocupacion_resumen WHERE pais = ? AND ciudad = ? AND nombre_hotel = ? AND anio = ?");
            var result2 = session.Execute(query2.Bind(pais, ciudad, hotel, anio));

            if (dgv_ocupacion.Columns.Count == 0)
            {
                dgv_ocupacion.ColumnCount = 5;
                dgv_ocupacion.Columns[0].Name = "Ciudad";
                dgv_ocupacion.Columns[1].Name = "Hotel";
                dgv_ocupacion.Columns[2].Name = "Año";
                dgv_ocupacion.Columns[3].Name = "Mes";
                dgv_ocupacion.Columns[4].Name = "% de ocupaciónn";
            }

            dgv_resumen.Rows.Clear();
            foreach (var row in result2)
            {
                dgv_resumen.Rows.Add(
                    row.GetValue<string>("ciudad"),
                    row.GetValue<string>("nombre_hotel"),
                    row.GetValue<int>("anio"),
                    row.GetValue<string>("mes"),
                    row.GetValue<decimal>("porcentaje_ocupacion_total")
                );
            }
        }
    }
}
