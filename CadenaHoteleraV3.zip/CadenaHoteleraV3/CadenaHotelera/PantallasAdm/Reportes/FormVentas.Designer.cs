﻿namespace CadenaHotelera.PantallasAdm.Reportes
{
    partial class FormVentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_ventas = new DataGridView();
            label3 = new Label();
            cmb_hotel = new ComboBox();
            label2 = new Label();
            cmb_ciudad = new ComboBox();
            label1 = new Label();
            cmb_anio = new ComboBox();
            label8 = new Label();
            cmb_pais = new ComboBox();
            btn_buscar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_ventas).BeginInit();
            SuspendLayout();
            // 
            // dgv_ventas
            // 
            dgv_ventas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_ventas.Location = new Point(12, 60);
            dgv_ventas.Name = "dgv_ventas";
            dgv_ventas.Size = new Size(1024, 466);
            dgv_ventas.TabIndex = 63;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(473, 17);
            label3.Name = "label3";
            label3.Size = new Size(49, 21);
            label3.TabIndex = 62;
            label3.Text = " Hotel";
            // 
            // cmb_hotel
            // 
            cmb_hotel.FormattingEnabled = true;
            cmb_hotel.Location = new Point(528, 17);
            cmb_hotel.Name = "cmb_hotel";
            cmb_hotel.Size = new Size(126, 23);
            cmb_hotel.TabIndex = 61;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(210, 17);
            label2.Name = "label2";
            label2.Size = new Size(57, 21);
            label2.TabIndex = 60;
            label2.Text = "Ciudad";
            // 
            // cmb_ciudad
            // 
            cmb_ciudad.FormattingEnabled = true;
            cmb_ciudad.Location = new Point(273, 17);
            cmb_ciudad.Name = "cmb_ciudad";
            cmb_ciudad.Size = new Size(194, 23);
            cmb_ciudad.TabIndex = 59;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(667, 19);
            label1.Name = "label1";
            label1.Size = new Size(36, 21);
            label1.TabIndex = 58;
            label1.Text = "Año";
            // 
            // cmb_anio
            // 
            cmb_anio.FormattingEnabled = true;
            cmb_anio.Location = new Point(709, 19);
            cmb_anio.Name = "cmb_anio";
            cmb_anio.Size = new Size(126, 23);
            cmb_anio.TabIndex = 57;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(21, 17);
            label8.Name = "label8";
            label8.Size = new Size(43, 21);
            label8.TabIndex = 56;
            label8.Text = " País";
            // 
            // cmb_pais
            // 
            cmb_pais.FormattingEnabled = true;
            cmb_pais.Location = new Point(70, 17);
            cmb_pais.Name = "cmb_pais";
            cmb_pais.Size = new Size(126, 23);
            cmb_pais.TabIndex = 55;
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_buscar.Location = new Point(863, 10);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(125, 35);
            btn_buscar.TabIndex = 72;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // FormVentas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 538);
            Controls.Add(btn_buscar);
            Controls.Add(dgv_ventas);
            Controls.Add(label3);
            Controls.Add(cmb_hotel);
            Controls.Add(label2);
            Controls.Add(cmb_ciudad);
            Controls.Add(label1);
            Controls.Add(cmb_anio);
            Controls.Add(label8);
            Controls.Add(cmb_pais);
            Name = "FormVentas";
            Text = "FormVentas";
            ((System.ComponentModel.ISupportInitialize)dgv_ventas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgv_ventas;
        private Label label3;
        private ComboBox cmb_hotel;
        private Label label2;
        private ComboBox cmb_ciudad;
        private Label label1;
        private ComboBox cmb_anio;
        private Label label8;
        private ComboBox cmb_pais;
        private Button btn_buscar;
    }
}