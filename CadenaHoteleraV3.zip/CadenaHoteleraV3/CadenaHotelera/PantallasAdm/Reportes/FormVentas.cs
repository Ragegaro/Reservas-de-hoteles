﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasAdm.Reportes
{
    public partial class FormVentas : Form
    {
        public FormVentas()
        {
            InitializeComponent();
        }

        private void FormVentas_Load(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            // País
            cmb_pais.Items.Clear();
            var paises = session.Execute("SELECT DISTINCT pais FROM  ventas_hotel");
            foreach (var row in paises)
                cmb_pais.Items.Add(row.GetValue<string>("pais"));

            // Año
            cmb_anio.Items.Clear();
            int actual = DateTime.Now.Year;
            for (int i = actual; i >= actual - 10; i--)
                cmb_anio.Items.Add(i.ToString());
        }

        private void cmb_pais_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_ciudad.Items.Clear();
            string pais = cmb_pais.SelectedItem.ToString();
            var session = CassandraConnector.Session;

            var prepared = session.Prepare("SELECT DISTINCT ciudad FROM  ocupacion_hotel WHERE pais = ?");
            var ciudades = session.Execute(prepared.Bind(pais));

            foreach (var row in ciudades)
                cmb_ciudad.Items.Add(row.GetValue<string>("ciudad"));
        }

        private void cmb_ciudad_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_hotel.Items.Clear();
            string pais = cmb_pais.SelectedItem.ToString();
            string ciudad = cmb_ciudad.SelectedItem.ToString();
            var session = CassandraConnector.Session;

            var prepared = session.Prepare("SELECT DISTINCT nombre_hotel FROM  ocupacion_hotel WHERE pais = ? AND ciudad = ?");
            var hoteles = session.Execute(prepared.Bind(pais, ciudad));

            foreach (var row in hoteles)
                cmb_hotel.Items.Add(row.GetValue<string>("nombre_hotel"));
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            string pais = cmb_pais.Text;
            string ciudad = cmb_ciudad.Text;
            string hotel = cmb_hotel.Text;
            int anio = int.Parse(cmb_anio.Text);

            var session = CassandraConnector.Session;
            var query = session.Prepare("SELECT * FROM  ventas_hotel WHERE pais = ? AND ciudad = ? AND nombre_hotel = ? AND anio = ?");
            var result = session.Execute(query.Bind(pais, ciudad, hotel, anio));

            if (dgv_ventas.Columns.Count == 0)
            {
                dgv_ventas.ColumnCount = 8;
                dgv_ventas.Columns[0].Name = "Ciudad";
                dgv_ventas.Columns[1].Name = "Hotel";
                dgv_ventas.Columns[2].Name = "Año";
                dgv_ventas.Columns[3].Name = "Mes";
                dgv_ventas.Columns[4].Name = "Suma anticipo";
                dgv_ventas.Columns[5].Name = "Suma hospedaje";
                dgv_ventas.Columns[6].Name = "Suma servicios";
                dgv_ventas.Columns[7].Name = "Suma total";
            }

            dgv_ventas.Rows.Clear();
            foreach (var row in result)
            {
                dgv_ventas.Rows.Add(
                    row.GetValue<string>("ciudad"),
                    row.GetValue<string>("nombre_hotel"),
                    row.GetValue<int>("anio"),
                    row.GetValue<string>("mes"),
                    row.GetValue<decimal>("suma_anticipos"),
                    row.GetValue<decimal>("suma_hospedaje"),
                    row.GetValue<decimal>("suma_servicios"),
                    row.GetValue<decimal>("suma_total")
                );
            }
        }
    }
}
