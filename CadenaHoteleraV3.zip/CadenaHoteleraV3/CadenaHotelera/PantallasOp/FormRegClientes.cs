﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.Pantallas
{
    public partial class FormRegClientes : Form
    {
        public FormRegClientes()
        {
            InitializeComponent();
            CargarClientes();
            CargarPaises();
        }

        private void CargarPaises()
        {
            var session = CassandraConnector.Session;
            var query = session.Prepare("SELECT DISTINCT pais FROM paises_estados");
            var result = session.Execute(query.Bind());

            cb_pais.Items.Clear();
            foreach (var row in result)
            {
                cb_pais.Items.Add(row.GetValue<string>("pais"));
            }
        }

        private void cb_pais_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_pais.SelectedItem == null)
                return;

            string paisSeleccionado = cb_pais.SelectedItem.ToString();

            var session = CassandraConnector.Session;
            var query = session.Prepare("SELECT estado FROM paises_estados WHERE pais = ?");
            var result = session.Execute(query.Bind(paisSeleccionado));

            cb_estado.Items.Clear();

            foreach (var row in result)
            {
                cb_estado.Items.Add(row.GetValue<string>("estado"));
            }
        }

        private void CargarClientes()
        {
            var session = CassandraConnector.Session;
            string query = "SELECT rfc, nombres, apellido_paterno, apellido_materno, pais, estado, ciudad, email FROM huespedes";

            var result = session.Execute(query);

            if (dgv_clientes.Columns.Count == 0)
            {
                dgv_clientes.ColumnCount = 8;
                dgv_clientes.Columns[0].Name = "RFC";
                dgv_clientes.Columns[1].Name = "Nombres";
                dgv_clientes.Columns[2].Name = "Apellido Paterno";
                dgv_clientes.Columns[3].Name = "Apellido Materno";
                dgv_clientes.Columns[4].Name = "País";
                dgv_clientes.Columns[5].Name = "Estado";
                dgv_clientes.Columns[6].Name = "Ciudad";
                dgv_clientes.Columns[7].Name = "Email";
            }

            dgv_clientes.Rows.Clear();

            foreach (var row in result)
            {
                dgv_clientes.Rows.Add(
                    row.GetValue<string>("rfc"),
                    row.GetValue<string>("nombres"),
                    row.GetValue<string>("apellido_paterno"),
                    row.GetValue<string>("apellido_materno"),
                    row.GetValue<string>("pais"),
                    row.GetValue<string>("estado"),
                    row.GetValue<string>("ciudad"),
                    row.GetValue<string>("email")
                );
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
                        var session = CassandraConnector.Session;

            string query = @"INSERT INTO  huespedes (
        rfc, nombres, apellido_paterno, apellido_materno, pais, estado, ciudad,
        email, telefono_casa, telefono_celular, fecha_nacimiento, estado_civil, fecha_registro
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            DateTime epoch = new DateTime(1970, 1, 1);
            int diasDesde1970 = (int)(dtp_nacimiento.Value.Date - epoch).TotalDays;


            var prepared = session.Prepare(query);
            var statement = prepared.Bind(
                txt_RFC.Text,
                txt_Nombre.Text,
                txt_ApPat.Text,
                txt_ApMat.Text,
                cb_pais.Text,
                cb_estado.Text,
                txt_ciudad.Text,
                txt_Email.Text,
                txt_telCas.Text,
                txt_telCel.Text,
                diasDesde1970,
                cb_estadoCivil.Text,
                //usuarioActual,
                DateTime.Now
            );
            

            session.Execute(statement);
            CargarClientes();
            MessageBox.Show("Cliente registrado.");
        }
    }
}
