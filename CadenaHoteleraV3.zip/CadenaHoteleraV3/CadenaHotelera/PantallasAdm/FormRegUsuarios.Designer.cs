﻿namespace CadenaHotelera.PantallasAdm
{
    partial class FormRegUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dtp_nacimiento = new DateTimePicker();
            txt_telCel = new TextBox();
            txt_telCasa = new TextBox();
            txt_email = new TextBox();
            txt_nomina = new TextBox();
            txt_contrasena = new TextBox();
            txt_apMat = new TextBox();
            txt_apPat = new TextBox();
            txt_nombre = new TextBox();
            btn_registrar = new Button();
            dgv_clientes = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgv_clientes).BeginInit();
            SuspendLayout();
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label11.Location = new Point(54, 307);
            label11.Name = "label11";
            label11.Size = new Size(151, 21);
            label11.TabIndex = 46;
            label11.Text = "Fecha de nacimiento:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(54, 391);
            label10.Name = "label10";
            label10.Size = new Size(120, 21);
            label10.TabIndex = 45;
            label10.Text = "Teléfono celular:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label9.Location = new Point(54, 349);
            label9.Name = "label9";
            label9.Size = new Size(123, 21);
            label9.TabIndex = 44;
            label9.Text = "Teléfono de casa:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(54, 55);
            label8.Name = "label8";
            label8.Size = new Size(59, 21);
            label8.TabIndex = 43;
            label8.Text = "E-mail:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(54, 265);
            label7.Name = "label7";
            label7.Size = new Size(73, 21);
            label7.TabIndex = 42;
            label7.Text = "Nómina :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label6.Location = new Point(54, 97);
            label6.Name = "label6";
            label6.Size = new Size(92, 21);
            label6.TabIndex = 41;
            label6.Text = "Contraseña:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(54, 223);
            label3.Name = "label3";
            label3.Size = new Size(129, 21);
            label3.TabIndex = 38;
            label3.Text = "Apellido materno:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(54, 181);
            label2.Name = "label2";
            label2.Size = new Size(124, 21);
            label2.TabIndex = 37;
            label2.Text = "Apellido paterno:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(54, 139);
            label1.Name = "label1";
            label1.Size = new Size(88, 21);
            label1.TabIndex = 36;
            label1.Text = "Nombre(s):";
            // 
            // dtp_nacimiento
            // 
            dtp_nacimiento.Location = new Point(213, 309);
            dtp_nacimiento.Name = "dtp_nacimiento";
            dtp_nacimiento.Size = new Size(200, 23);
            dtp_nacimiento.TabIndex = 35;
            // 
            // txt_telCel
            // 
            txt_telCel.Location = new Point(213, 393);
            txt_telCel.Name = "txt_telCel";
            txt_telCel.Size = new Size(119, 23);
            txt_telCel.TabIndex = 32;
            // 
            // txt_telCasa
            // 
            txt_telCasa.Location = new Point(213, 351);
            txt_telCasa.Name = "txt_telCasa";
            txt_telCasa.Size = new Size(119, 23);
            txt_telCasa.TabIndex = 31;
            // 
            // txt_email
            // 
            txt_email.Location = new Point(213, 57);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(224, 23);
            txt_email.TabIndex = 30;
            // 
            // txt_nomina
            // 
            txt_nomina.Location = new Point(213, 267);
            txt_nomina.Name = "txt_nomina";
            txt_nomina.Size = new Size(224, 23);
            txt_nomina.TabIndex = 29;
            // 
            // txt_contrasena
            // 
            txt_contrasena.Location = new Point(213, 99);
            txt_contrasena.Name = "txt_contrasena";
            txt_contrasena.Size = new Size(224, 23);
            txt_contrasena.TabIndex = 28;
            // 
            // txt_apMat
            // 
            txt_apMat.Location = new Point(213, 225);
            txt_apMat.Name = "txt_apMat";
            txt_apMat.Size = new Size(224, 23);
            txt_apMat.TabIndex = 27;
            // 
            // txt_apPat
            // 
            txt_apPat.Location = new Point(213, 183);
            txt_apPat.Name = "txt_apPat";
            txt_apPat.Size = new Size(224, 23);
            txt_apPat.TabIndex = 26;
            // 
            // txt_nombre
            // 
            txt_nombre.Location = new Point(213, 141);
            txt_nombre.Name = "txt_nombre";
            txt_nombre.Size = new Size(224, 23);
            txt_nombre.TabIndex = 25;
            // 
            // btn_registrar
            // 
            btn_registrar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_registrar.Location = new Point(872, 527);
            btn_registrar.Name = "btn_registrar";
            btn_registrar.Size = new Size(125, 35);
            btn_registrar.TabIndex = 70;
            btn_registrar.Text = "Registrar";
            btn_registrar.UseVisualStyleBackColor = true;
            btn_registrar.Click += btn_registrar_Click;
            // 
            // dgv_clientes
            // 
            dgv_clientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_clientes.Location = new Point(495, 49);
            dgv_clientes.Name = "dgv_clientes";
            dgv_clientes.Size = new Size(541, 367);
            dgv_clientes.TabIndex = 71;
            // 
            // FormRegUsuarios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(dgv_clientes);
            Controls.Add(btn_registrar);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dtp_nacimiento);
            Controls.Add(txt_telCel);
            Controls.Add(txt_telCasa);
            Controls.Add(txt_email);
            Controls.Add(txt_nomina);
            Controls.Add(txt_contrasena);
            Controls.Add(txt_apMat);
            Controls.Add(txt_apPat);
            Controls.Add(txt_nombre);
            Name = "FormRegUsuarios";
            Text = "FormRegUsuarios";
            ((System.ComponentModel.ISupportInitialize)dgv_clientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label3;
        private Label label2;
        private Label label1;
        private DateTimePicker dtp_nacimiento;
        private TextBox txt_telCel;
        private TextBox txt_telCasa;
        private TextBox txt_email;
        private TextBox txt_nomina;
        private TextBox txt_contrasena;
        private TextBox txt_apMat;
        private TextBox txt_apPat;
        private TextBox txt_nombre;
        private Button btn_registrar;
        private DataGridView dgv_clientes;
    }
}