﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasAdm
{
    public partial class FormRegHoteles : Form
    {
        public FormRegHoteles()
        {
            InitializeComponent();
            InicializarDataGridViewHabitaciones();
            chlb_servAdi.Items.AddRange(new string[] {
                "Gimnasio",
                "WiFi",
                "Servicio al cuarto",
                "Renta de películas",
                "Masajes",
                "Restaurantes"
            });
            CargarPaises();
        }

        private void InicializarDataGridViewHabitaciones()
        {
            dgv_habitaciones.Columns.Clear();

            dgv_habitaciones.Columns.Add("tipo", "Tipo de habitación");
            dgv_habitaciones.Columns.Add("caracteristicas", "Características");
            dgv_habitaciones.Columns.Add("amenidades", "Amenidades");
            dgv_habitaciones.Columns.Add("cantidad_habitaciones", "Cantidad de habitaciones");
            dgv_habitaciones.Columns.Add("costo", "Costo");

            // Opcional: que no se puedan editar las celdas en el DGV directamente
            dgv_habitaciones.ReadOnly = true;
        }

        private void btn_agregarHabitacion_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_tipo.Text) ||
        string.IsNullOrWhiteSpace(txt_caract.Text) ||
        string.IsNullOrWhiteSpace(txt_amenidades.Text) ||
        string.IsNullOrWhiteSpace(txt_cantidadHabi.Text) ||
        string.IsNullOrWhiteSpace(txt_costo.Text))
            {
                MessageBox.Show("Por favor, llena todos los campos de la habitación antes de agregarla.");
                return;
            }

            // Agregar fila al DataGridView
            dgv_habitaciones.Rows.Add(
                txt_tipo.Text,
                txt_caract.Text,
                txt_amenidades.Text,
                txt_cantidadHabi.Text,
                txt_costo.Text
            );

            // Limpiar los TextBox para agregar otra habitación
            txt_tipo.Clear();
            txt_caract.Clear();
            txt_amenidades.Clear();
            txt_cantidadHabi.Clear();
            txt_costo.Clear();
        }

        private void btn_eliminarHabitacion_Click_1(object sender, EventArgs e)
        {
            if (dgv_habitaciones.CurrentRow != null)
            {
                dgv_habitaciones.Rows.Remove(dgv_habitaciones.CurrentRow);
            }
        }

        private void FormRegHoteles_Load(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            var query = "SELECT DISTINCT pais FROM  paises_estados";
            var result = session.Execute(query);

            cb_pais.Items.Clear();
            foreach (var row in result)
            {
                cb_pais.Items.Add(row.GetValue<string>("pais"));
            }
        }

        private void CargarPaises()
        {
            var session = CassandraConnector.Session;
            var query = session.Prepare("SELECT DISTINCT pais FROM paises_estados");
            var result = session.Execute(query.Bind());

            cb_pais.Items.Clear();
            foreach (var row in result)
            {
                cb_pais.Items.Add(row.GetValue<string>("pais"));
            }
        }

        private void cmb_pais_SelectedIndexChanged(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            string query = "SELECT estado FROM  paises_estados WHERE pais = ?";
            var prepared = session.Prepare(query);
            var result = session.Execute(prepared.Bind(cb_pais.Text));

            cb_estado.Items.Clear();
            foreach (var row in result)
            {
                cb_estado.Items.Add(row.GetValue<string>("estado"));
            }
        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            string query = @"INSERT INTO hoteles (
        nombre_hotel, pais, estado, ciudad, domicilio, numero_pisos,
        zona_turistica, servicios_adicionales, fecha_registro
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            var prepared = session.Prepare(query);
            var statement = prepared.Bind(
                txt_nomHotel.Text,
                cb_pais.Text,
                cb_estado.Text,
                txt_ciudad.Text,
                txt_domicilio.Text,
                int.Parse(txt_numPisos.Text),
                txt_zonaTur.Text,
                chlb_servAdi.CheckedItems.Cast<string>().ToList(),
                DateTime.Now
            //DateTime.Parse(dtp_inicio.Text)
            );

            session.Execute(statement);


            foreach (DataGridViewRow row in dgv_habitaciones.Rows)
            {
                if (row.IsNewRow) continue;

                string tipo = row.Cells["tipo"].Value?.ToString();
                string caracteristicas = row.Cells["caracteristicas"].Value?.ToString();
                List<string> amenidades = row.Cells["amenidades"].Value?.ToString()
                    .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(a => a.Trim())
                    .ToList();

                int cantidad_habitaciones = int.Parse(row.Cells["cantidad_habitaciones"].Value?.ToString());
                decimal precio = decimal.Parse(row.Cells["costo"].Value?.ToString());

                // Insertar en habitaciones_por_hotel
                var insertQuery = "INSERT INTO habitaciones_por_hotel (nombre_hotel, nombre_tipo, cantidad_habitaciones, precio) " +
                                  "VALUES (?, ?, ?, ?)";

                prepared = session.Prepare(insertQuery);
                statement = prepared.Bind(txt_nomHotel.Text.Trim(), tipo, cantidad_habitaciones, precio);
                session.Execute(statement);

                // Insertar en tipos_habitacion (si quieres que se registre también como tipo global)
                var insertTipoQuery = @"INSERT INTO tipos_habitacion (
            nombre_tipo, caracteristicas, amenidades, cantidad_habitaciones, precio, fecha_registro
        ) VALUES (?, ?, ?, ?, ?, ?)";

                prepared = session.Prepare(insertTipoQuery);
                statement = prepared.Bind(tipo, caracteristicas, amenidades, cantidad_habitaciones, precio, DateTime.Now);
                session.Execute(statement);
            }
            MessageBox.Show("Hotel registrado correctamente.");


        }

        private void cb_pais_SelectedIndexChanged(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            string query = "SELECT estado FROM  paises_estados WHERE pais = ?";
            var prepared = session.Prepare(query);
            var result = session.Execute(prepared.Bind(cb_pais.Text));

            cb_estado.Items.Clear();
            foreach (var row in result)
            {
                cb_estado.Items.Add(row.GetValue<string>("estado"));
            }
        }
    }
}
