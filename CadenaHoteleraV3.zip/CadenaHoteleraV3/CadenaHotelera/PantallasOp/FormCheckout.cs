﻿using Cassandra;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp
{
    public partial class FormCheckout : Form
    {
        public FormCheckout()
        {
            InitializeComponent();
        }

        private void btn_confCheckOut_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Tag == null)
            {
                MessageBox.Show("Primero busca una reservación.");
                return;
            }

                        var session = CassandraConnector.Session;
            dynamic datos = txt_codigo.Tag;

            // (Opcional) Calcular días
            int dias = (int)(datos.FechaSalida - datos.FechaEntrada).TotalDays;
            if (dias <= 0) dias = 1;

            // (Opcional) Simular tarifa por tipo de cuarto
            decimal precioPorDia = datos.Tipo switch
            {
                "Estándar" => 800,
                "Suite" => 1600,
                "Deluxe" => 2400,
                _ => 1000
            };
            decimal total = dias * precioPorDia;

            string query = @"INSERT INTO  checkout (
        codigo_reserva, fecha_checkout, id_habitacion, estado,
        nombre_hotel, rfc_huesped, total_pago
    ) VALUES (?, ?, ?, ?, ?, ?, ?)";

            var prepared = session.Prepare(query);
            var statement = prepared.Bind(
                datos.Codigo,
                DateTime.Now,
                datos.Habitacion,
                "Finalizado",
                datos.Hotel,
                datos.RFC,
                total
            );

            session.Execute(statement);

            // Actualizar estado en reservaciones
            string update = "UPDATE  reservaciones SET estatus = ? WHERE codigo_reserva = ?";
            session.Execute(session.Prepare(update).Bind("Finalizado", datos.Codigo));

            MessageBox.Show($"Check-out registrado. Total a pagar: ${total}");
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            if (!Guid.TryParse(txt_codigo.Text, out Guid codigo))
            {
                MessageBox.Show("Código inválido.");
                return;
            }

                        var session = CassandraConnector.Session;

            // 1. Obtener check-in
            string qCheckin = "SELECT * FROM  checkin WHERE codigo_reserva = ?";
            var resCheckin = session.Execute(session.Prepare(qCheckin).Bind(codigo)).FirstOrDefault();

            if (resCheckin == null)
            {
                MessageBox.Show("No se encontró un check-in para esta reservación.");
                return;
            }

            // 2. Obtener reservación
            string qReserva = "SELECT * FROM  reservaciones WHERE codigo_reserva = ?";
            var resReserva = session.Execute(session.Prepare(qReserva).Bind(codigo)).FirstOrDefault();

            if (resReserva == null)
            {
                MessageBox.Show("Reservación no encontrada.");
                return;
            }

            // Mostrar en pantalla
            txt_hotel.Text = resCheckin.GetValue<string>("nombre_hotel");
            txt_habitacion.Text = resCheckin.GetValue<string>("id_habitacion");
            var fechaEntrada = resReserva.GetValue<Cassandra.LocalDate>("fecha_entrada");
            var fechaSalida = resReserva.GetValue<Cassandra.LocalDate>("fecha_salida");

            txt_fechaEntrada.Text = new DateTime(fechaEntrada.Year, fechaEntrada.Month, fechaEntrada.Day).ToShortDateString();
            txt_fechaSalida.Text = new DateTime(fechaSalida.Year, fechaSalida.Month, fechaSalida.Day).ToShortDateString();

            txt_tipo.Text = resReserva.GetValue<string>("tipo_cuarto");

            // Guardar temporalmente los datos necesarios
            txt_codigo.Tag = new
            {
                Codigo = codigo,
                Hotel = resCheckin.GetValue<string>("nombre_hotel"),
                Habitacion = resCheckin.GetValue<string>("id_habitacion"),
                RFC = resReserva.GetValue<string>("rfc_huesped"),
                FechaEntrada = new DateTime(fechaEntrada.Year, fechaEntrada.Month, fechaEntrada.Day),
                FechaSalida = new DateTime(fechaSalida.Year, fechaSalida.Month, fechaSalida.Day),
                Tipo = resReserva.GetValue<string>("tipo_cuarto")
            };
        }
    }
}
