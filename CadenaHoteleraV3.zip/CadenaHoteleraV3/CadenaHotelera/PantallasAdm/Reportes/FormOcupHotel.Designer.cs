﻿namespace CadenaHotelera.PantallasAdm.Reportes
{
    partial class FormOcupHotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label8 = new Label();
            cmb_pais = new ComboBox();
            label1 = new Label();
            cmb_anio = new ComboBox();
            label2 = new Label();
            cmb_ciudad = new ComboBox();
            label3 = new Label();
            cmb_hotel = new ComboBox();
            dgv_ocupacion = new DataGridView();
            dgv_resumen = new DataGridView();
            btn_buscar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_ocupacion).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv_resumen).BeginInit();
            SuspendLayout();
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(21, 21);
            label8.Name = "label8";
            label8.Size = new Size(43, 21);
            label8.TabIndex = 46;
            label8.Text = " País";
            //label8.Click += label8_Click;
            // 
            // cmb_pais
            // 
            cmb_pais.FormattingEnabled = true;
            cmb_pais.Location = new Point(70, 21);
            cmb_pais.Name = "cmb_pais";
            cmb_pais.Size = new Size(126, 23);
            cmb_pais.TabIndex = 45;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(658, 21);
            label1.Name = "label1";
            label1.Size = new Size(36, 21);
            label1.TabIndex = 48;
            label1.Text = "Año";
            // 
            // cmb_anio
            // 
            cmb_anio.FormattingEnabled = true;
            cmb_anio.Location = new Point(700, 21);
            cmb_anio.Name = "cmb_anio";
            cmb_anio.Size = new Size(126, 23);
            cmb_anio.TabIndex = 47;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(206, 21);
            label2.Name = "label2";
            label2.Size = new Size(57, 21);
            label2.TabIndex = 50;
            label2.Text = "Ciudad";
            // 
            // cmb_ciudad
            // 
            cmb_ciudad.FormattingEnabled = true;
            cmb_ciudad.Location = new Point(269, 21);
            cmb_ciudad.Name = "cmb_ciudad";
            cmb_ciudad.Size = new Size(194, 23);
            cmb_ciudad.TabIndex = 49;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(469, 21);
            label3.Name = "label3";
            label3.Size = new Size(49, 21);
            label3.TabIndex = 52;
            label3.Text = " Hotel";
            // 
            // cmb_hotel
            // 
            cmb_hotel.FormattingEnabled = true;
            cmb_hotel.Location = new Point(524, 21);
            cmb_hotel.Name = "cmb_hotel";
            cmb_hotel.Size = new Size(126, 23);
            cmb_hotel.TabIndex = 51;
            // 
            // dgv_ocupacion
            // 
            dgv_ocupacion.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_ocupacion.Location = new Point(12, 55);
            dgv_ocupacion.Name = "dgv_ocupacion";
            dgv_ocupacion.Size = new Size(1024, 296);
            dgv_ocupacion.TabIndex = 53;
            // 
            // dgv_resumen
            // 
            dgv_resumen.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_resumen.Location = new Point(12, 373);
            dgv_resumen.Name = "dgv_resumen";
            dgv_resumen.Size = new Size(1024, 153);
            dgv_resumen.TabIndex = 54;
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_buscar.Location = new Point(842, 14);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(125, 35);
            btn_buscar.TabIndex = 72;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // FormOcupHotel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 538);
            Controls.Add(btn_buscar);
            Controls.Add(dgv_resumen);
            Controls.Add(dgv_ocupacion);
            Controls.Add(label3);
            Controls.Add(cmb_hotel);
            Controls.Add(label2);
            Controls.Add(cmb_ciudad);
            Controls.Add(label1);
            Controls.Add(cmb_anio);
            Controls.Add(label8);
            Controls.Add(cmb_pais);
            Name = "FormOcupHotel";
            Text = "FormOcupHotel";
            ((System.ComponentModel.ISupportInitialize)dgv_ocupacion).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv_resumen).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label8;
        private ComboBox cmb_pais;
        private Label label1;
        private ComboBox cmb_anio;
        private Label label2;
        private ComboBox cmb_ciudad;
        private Label label3;
        private ComboBox cmb_hotel;
        private DataGridView dgv_ocupacion;
        private DataGridView dgv_resumen;
        private Button btn_buscar;
    }
}