﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace CadenaHotelera
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            var session = CassandraConnector.Session;

            string query = "SELECT contrasena, rol FROM usuarios WHERE email = ?";
            var prepared = session.Prepare(query);
            var statement = prepared.Bind(txt_email.Text);

            var result = session.Execute(statement);
            var row = result.FirstOrDefault();

            if (row != null && row.GetValue<string>("contrasena") == txt_contra.Text)
            {
                string tipoUsuario = row.GetValue<string>("rol").ToLower();

                MessageBox.Show("Inicio de sesión exitoso.");

                // Abrir la pantalla correspondiente
                if (tipoUsuario == "admin")
                {
                    MenuAdm menu = new MenuAdm();
                    menu.Show();
                }
                else if (tipoUsuario == "operador")
                {
                    MenuOp menu = new MenuOp();
                    menu.Show();
                }
                else
                {
                    MessageBox.Show("Tipo de usuario no reconocido.");
                }

                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.");
            }
        }
    }
}
