﻿namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    partial class FormReservasPrepago
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_pagar = new Button();
            label10 = new Label();
            txt_anticipo = new TextBox();
            label1 = new Label();
            lbl_codigo = new Label();
            label2 = new Label();
            txt_total = new TextBox();
            dgv_resumen = new DataGridView();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgv_resumen).BeginInit();
            SuspendLayout();
            // 
            // btn_pagar
            // 
            btn_pagar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_pagar.Location = new Point(80, 372);
            btn_pagar.Name = "btn_pagar";
            btn_pagar.Size = new Size(168, 35);
            btn_pagar.TabIndex = 70;
            btn_pagar.Text = "Pagar";
            btn_pagar.UseVisualStyleBackColor = true;
            btn_pagar.Click += btn_pagar_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(32, 297);
            label10.Name = "label10";
            label10.Size = new Size(70, 21);
            label10.TabIndex = 69;
            label10.Text = "Anticipo:";
            // 
            // txt_anticipo
            // 
            txt_anticipo.Location = new Point(129, 297);
            txt_anticipo.Name = "txt_anticipo";
            txt_anticipo.Size = new Size(119, 23);
            txt_anticipo.TabIndex = 68;
            txt_anticipo.TextChanged += tb_telCel_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(626, 323);
            label1.Name = "label1";
            label1.Size = new Size(135, 21);
            label1.TabIndex = 71;
            label1.Text = "Código de reserva:";
            // 
            // lbl_codigo
            // 
            lbl_codigo.AutoSize = true;
            lbl_codigo.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            lbl_codigo.Location = new Point(626, 355);
            lbl_codigo.Name = "lbl_codigo";
            lbl_codigo.Size = new Size(35, 21);
            lbl_codigo.TabIndex = 72;
            lbl_codigo.Text = "-----";
            lbl_codigo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(32, 254);
            label2.Name = "label2";
            label2.Size = new Size(91, 21);
            label2.TabIndex = 74;
            label2.Text = "Precio total:";
            // 
            // txt_total
            // 
            txt_total.Location = new Point(129, 254);
            txt_total.Name = "txt_total";
            txt_total.ReadOnly = true;
            txt_total.Size = new Size(119, 23);
            txt_total.TabIndex = 73;
            // 
            // dgv_resumen
            // 
            dgv_resumen.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_resumen.Location = new Point(30, 52);
            dgv_resumen.Name = "dgv_resumen";
            dgv_resumen.Size = new Size(978, 183);
            dgv_resumen.TabIndex = 75;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(30, 28);
            label3.Name = "label3";
            label3.Size = new Size(186, 21);
            label3.TabIndex = 76;
            label3.Text = "Resumen final de reserva:";
            // 
            // FormReservasPrepago
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 526);
            Controls.Add(label3);
            Controls.Add(dgv_resumen);
            Controls.Add(label2);
            Controls.Add(txt_total);
            Controls.Add(lbl_codigo);
            Controls.Add(label1);
            Controls.Add(btn_pagar);
            Controls.Add(label10);
            Controls.Add(txt_anticipo);
            Name = "FormReservasPrepago";
            Text = "FormReservasPrepago";
            ((System.ComponentModel.ISupportInitialize)dgv_resumen).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_pagar;
        private Label label10;
        private TextBox txt_anticipo;
        private Label label1;
        private Label lbl_codigo;
        private Label label2;
        private TextBox txt_total;
        private DataGridView dgv_resumen;
        private Label label3;
    }
}