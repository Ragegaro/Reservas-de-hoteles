﻿using CadenaHotelera.PantallasAdm.Reportes;
using CadenaHotelera.PantallasOp.PantallasReservas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp
{
    public partial class FormReservasUsuario : Form
    {
        int menu = 1;
        private Form currentChildForm;
        public FormReservasUsuario()
        {
            InitializeComponent();
            OpenChildForm(new FormReservasHuesped());
        }

        public class DatosReserva
        {
            public string RFC { get; set; }
            public string Hotel { get; set; }
            public string TipoCuarto { get; set; }
            public DateTime FechaEntrada { get; set; }
            public DateTime FechaSalida { get; set; }
            public int CantidadPersonas { get; set; }
            public decimal MontoPrepago { get; set; }
        }

        public DatosReserva datosReserva = new DatosReserva();

        private void OpenChildForm(Form childForm)
        {
            if (currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelReservas.Controls.Add(childForm);
            panelReservas.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void InsertarReservacion()
        {
                        var session = CassandraConnector.Session;

            // Generar código único (UUID)
            var codigoReserva = Guid.NewGuid();

            string query = @"INSERT INTO  reservaciones (
             codigo_reserva, rfc_huesped, nombre_hotel, tipo_cuarto,
             fecha_entrada, fecha_salida, cantidad_personas,
             monto_prepago, fecha_registro, estatus
             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            var prepared = session.Prepare(query);

            var statement = prepared.Bind(
                codigoReserva,
                datosReserva.RFC,                 // desde subpantalla huesped
                datosReserva.Hotel,               // desde subpantalla hoteles
                datosReserva.TipoCuarto,          // desde subpantalla habitaciones
                datosReserva.FechaEntrada,        // desde subpantalla fechas
                datosReserva.FechaSalida,
                datosReserva.CantidadPersonas,    // desde subpantalla habitaciones
                datosReserva.MontoPrepago,        // desde subpantalla prepago
                //usuarioActual,
                DateTime.Now,
                "Activa"
            );

            session.Execute(statement);
            MessageBox.Show($"Reservación registrada. Código: {codigoReserva}");
        }


        //private void button2_Click(object sender, EventArgs e)
        //{
        //    OpenChildForm(new FormOcupHotel());
        //}

        private void btn_continuar_Click(object sender, EventArgs e)
        {
            if (menu < 5)
            {
                menu++;
            }
            ventanas();
        }

        private void btn_regresar_Click(object sender, EventArgs e)
        {
            if (menu > 1)
            {
                menu--;
            }
            ventanas();
        }

        private void ventanas()
        {
            switch (menu)
            { 
                case 1: OpenChildForm(new FormReservasHuesped());
                    break;
                case 2:
                    OpenChildForm(new FormReservaListaHoteles());
                    break;
                case 3:
                    OpenChildForm(new FormReservasListaHabi());
                    break;
                case 4:
                    OpenChildForm(new FormReservasFechas());
                    break;
                case 5:
                    OpenChildForm(new FormReservasPrepago());
                    break;
            }

        }
    }
}
