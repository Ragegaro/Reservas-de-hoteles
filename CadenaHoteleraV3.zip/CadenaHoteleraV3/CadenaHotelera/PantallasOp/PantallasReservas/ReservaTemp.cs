﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    public static class ReservaTemp
    {
        public static string RfcHuesped;
        public static string NombreCompleto;

        public static string HotelSeleccionado;
        public static string Ciudad;
        public static string Estado;
        public static string Pais;

        public static List<HabitacionReservada> Habitaciones = new List<HabitacionReservada>();
        public static DateTime FechaEntrada;
        public static DateTime FechaSalida;
    }

    public class HabitacionReservada
    {
        public string Tipo;
        public int Cantidad;
        public int Personas;
        public decimal PrecioUnitario;
    }
}
