﻿using Cassandra;
using System;

namespace CadenaHotelera
{
    public static class CassandraConnector
    {
        private static Cluster cluster;
        private static ISession session;

        // Establece la conexión al keyspace
        public static void Conectar()
        {
            if (session == null)
            {
                cluster = Cluster.Builder()
                    .AddContactPoint("localhost") // Cambia si tu Cassandra está en otra IP
                    .Build();

                session = cluster.Connect("basehoteles"); // Usa tu keyspace
            }
        }

        // Ejecuta un query directo (por ejemplo SELECT)
        public static RowSet Ejecutar(string query)
        {
            Conectar();
            return session.Execute(query);
        }

        // Ejecuta un query preparado (por ejemplo INSERT o UPDATE)
        public static RowSet EjecutarPreparado(string query, params object[] valores)
        {
            Conectar();
            var prepared = session.Prepare(query);
            var bound = prepared.Bind(valores);
            return session.Execute(bound);
        }

        public static ISession Session
        {
            get
            {
                Conectar();
                return session;
            }
        }
    }
}