﻿namespace CadenaHotelera.PantallasOp
{
    partial class FormCheckout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_confCheckOut = new Button();
            label8 = new Label();
            label7 = new Label();
            txt_tipo = new TextBox();
            txt_fechaSalida = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txt_fechaEntrada = new TextBox();
            txt_habitacion = new TextBox();
            txt_hotel = new TextBox();
            txt_codigo = new TextBox();
            btn_buscar = new Button();
            SuspendLayout();
            // 
            // btn_confCheckOut
            // 
            btn_confCheckOut.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_confCheckOut.Location = new Point(849, 508);
            btn_confCheckOut.Name = "btn_confCheckOut";
            btn_confCheckOut.Size = new Size(168, 35);
            btn_confCheckOut.TabIndex = 79;
            btn_confCheckOut.Text = "Confirmar Check-Out";
            btn_confCheckOut.UseVisualStyleBackColor = true;
            btn_confCheckOut.Click += btn_confCheckOut_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(48, 303);
            label8.Name = "label8";
            label8.Size = new Size(139, 21);
            label8.TabIndex = 76;
            label8.Text = "Tipo de habitación:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(48, 261);
            label7.Name = "label7";
            label7.Size = new Size(116, 21);
            label7.TabIndex = 75;
            label7.Text = "Fecha de salida:";
            // 
            // txt_tipo
            // 
            txt_tipo.Location = new Point(223, 305);
            txt_tipo.Name = "txt_tipo";
            txt_tipo.ReadOnly = true;
            txt_tipo.Size = new Size(224, 23);
            txt_tipo.TabIndex = 72;
            // 
            // txt_fechaSalida
            // 
            txt_fechaSalida.Location = new Point(223, 263);
            txt_fechaSalida.Name = "txt_fechaSalida";
            txt_fechaSalida.ReadOnly = true;
            txt_fechaSalida.Size = new Size(224, 23);
            txt_fechaSalida.TabIndex = 71;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(50, 57);
            label4.Name = "label4";
            label4.Size = new Size(167, 21);
            label4.TabIndex = 69;
            label4.Text = "Número de reservación";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(50, 214);
            label3.Name = "label3";
            label3.Size = new Size(128, 21);
            label3.TabIndex = 68;
            label3.Text = "Fecha de entrada:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(50, 173);
            label2.Name = "label2";
            label2.Size = new Size(83, 21);
            label2.TabIndex = 67;
            label2.Text = "Habitación";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(50, 132);
            label1.Name = "label1";
            label1.Size = new Size(50, 21);
            label1.TabIndex = 66;
            label1.Text = "Hotel:";
            // 
            // txt_fechaEntrada
            // 
            txt_fechaEntrada.Location = new Point(223, 216);
            txt_fechaEntrada.Name = "txt_fechaEntrada";
            txt_fechaEntrada.ReadOnly = true;
            txt_fechaEntrada.Size = new Size(224, 23);
            txt_fechaEntrada.TabIndex = 65;
            // 
            // txt_habitacion
            // 
            txt_habitacion.Location = new Point(223, 175);
            txt_habitacion.Name = "txt_habitacion";
            txt_habitacion.ReadOnly = true;
            txt_habitacion.Size = new Size(224, 23);
            txt_habitacion.TabIndex = 64;
            // 
            // txt_hotel
            // 
            txt_hotel.Location = new Point(223, 134);
            txt_hotel.Name = "txt_hotel";
            txt_hotel.ReadOnly = true;
            txt_hotel.Size = new Size(224, 23);
            txt_hotel.TabIndex = 63;
            // 
            // txt_codigo
            // 
            txt_codigo.Location = new Point(223, 55);
            txt_codigo.Name = "txt_codigo";
            txt_codigo.Size = new Size(224, 23);
            txt_codigo.TabIndex = 84;
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_buscar.Location = new Point(453, 46);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(70, 35);
            btn_buscar.TabIndex = 83;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // FormCheckout
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(txt_codigo);
            Controls.Add(btn_buscar);
            Controls.Add(btn_confCheckOut);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txt_tipo);
            Controls.Add(txt_fechaSalida);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txt_fechaEntrada);
            Controls.Add(txt_habitacion);
            Controls.Add(txt_hotel);
            Name = "FormCheckout";
            Text = "FormCheckout";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btn_confCheckOut;
        private Label label8;
        private Label label7;
        private TextBox txt_tipo;
        private TextBox txt_fechaSalida;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txt_fechaEntrada;
        private TextBox txt_habitacion;
        private TextBox txt_hotel;
        private TextBox txt_codigo;
        private Button btn_buscar;
    }
}