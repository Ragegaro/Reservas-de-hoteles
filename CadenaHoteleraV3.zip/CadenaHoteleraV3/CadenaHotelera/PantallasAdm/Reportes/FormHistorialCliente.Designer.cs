﻿namespace CadenaHotelera.PantallasAdm.Reportes
{
    partial class FormHistorialCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label8 = new Label();
            dgv_historial = new DataGridView();
            cmb_anio = new ComboBox();
            txt_email = new TextBox();
            label1 = new Label();
            btn_buscar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_historial).BeginInit();
            SuspendLayout();
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(12, 17);
            label8.Name = "label8";
            label8.Size = new Size(59, 21);
            label8.TabIndex = 44;
            label8.Text = "E-mail:";
            // 
            // dgv_historial
            // 
            dgv_historial.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_historial.Location = new Point(12, 76);
            dgv_historial.Name = "dgv_historial";
            dgv_historial.Size = new Size(1024, 448);
            dgv_historial.TabIndex = 65;
            dgv_historial.CellContentClick += dgv_historial_CellContentClick;
            // 
            // cmb_anio
            // 
            cmb_anio.FormattingEnabled = true;
            cmb_anio.Location = new Point(372, 19);
            cmb_anio.Name = "cmb_anio";
            cmb_anio.Size = new Size(144, 23);
            cmb_anio.TabIndex = 64;
            // 
            // txt_email
            // 
            txt_email.Location = new Point(77, 19);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(224, 23);
            txt_email.TabIndex = 66;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(330, 21);
            label1.Name = "label1";
            label1.Size = new Size(41, 21);
            label1.TabIndex = 67;
            label1.Text = "Año:";
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_buscar.Location = new Point(532, 10);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(125, 35);
            btn_buscar.TabIndex = 71;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // FormHistorialCliente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 538);
            Controls.Add(btn_buscar);
            Controls.Add(label1);
            Controls.Add(txt_email);
            Controls.Add(dgv_historial);
            Controls.Add(cmb_anio);
            Controls.Add(label8);
            Name = "FormHistorialCliente";
            Text = "FormHistorialCliente";
            ((System.ComponentModel.ISupportInitialize)dgv_historial).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label8;
        private DataGridView dgv_historial;
        private ComboBox cmb_anio;
        private TextBox txt_email;
        private Label label1;
        private Button btn_buscar;
    }
}