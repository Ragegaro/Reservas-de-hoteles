﻿namespace CadenaHotelera.PantallasOp
{
    partial class FormCheckin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            btn_confCheckIn = new Button();
            label5 = new Label();
            dgv_reserva = new DataGridView();
            btn_buscar = new Button();
            txt_codigo = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgv_reserva).BeginInit();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(52, 55);
            label4.Name = "label4";
            label4.Size = new Size(167, 21);
            label4.TabIndex = 22;
            label4.Text = "Número de reservación";
            // 
            // btn_confCheckIn
            // 
            btn_confCheckIn.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_confCheckIn.Location = new Point(851, 506);
            btn_confCheckIn.Name = "btn_confCheckIn";
            btn_confCheckIn.Size = new Size(168, 35);
            btn_confCheckIn.TabIndex = 47;
            btn_confCheckIn.Text = "Confirmar Check-In";
            btn_confCheckIn.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label5.Location = new Point(52, 96);
            label5.Name = "label5";
            label5.Size = new Size(155, 21);
            label5.TabIndex = 49;
            label5.Text = "Datos de reservación:";
            // 
            // dgv_reserva
            // 
            dgv_reserva.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_reserva.Location = new Point(52, 120);
            dgv_reserva.Name = "dgv_reserva";
            dgv_reserva.Size = new Size(967, 366);
            dgv_reserva.TabIndex = 62;
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_buscar.Location = new Point(455, 48);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(70, 35);
            btn_buscar.TabIndex = 63;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // txt_codigo
            // 
            txt_codigo.Location = new Point(225, 57);
            txt_codigo.Name = "txt_codigo";
            txt_codigo.Size = new Size(224, 23);
            txt_codigo.TabIndex = 64;
            // 
            // FormCheckin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(txt_codigo);
            Controls.Add(btn_buscar);
            Controls.Add(dgv_reserva);
            Controls.Add(label5);
            Controls.Add(btn_confCheckIn);
            Controls.Add(label4);
            Name = "FormCheckin";
            Text = "FormCheckin";
            ((System.ComponentModel.ISupportInitialize)dgv_reserva).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label4;
        private Button btn_confCheckIn;
        private Label label5;
        private DataGridView dgv_reserva;
        private Button btn_buscar;
        private TextBox txt_codigo;
    }
}