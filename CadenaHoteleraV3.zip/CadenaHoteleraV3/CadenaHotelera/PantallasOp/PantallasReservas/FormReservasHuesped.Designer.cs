﻿namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    partial class FormReservasHuesped
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_seleccionar = new Button();
            txt_busqueda = new TextBox();
            btn_buscar = new Button();
            label4 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txt_telCel = new TextBox();
            txt_telCasa = new TextBox();
            txt_email = new TextBox();
            txt_rfc = new TextBox();
            txt_apMat = new TextBox();
            txt_apPat = new TextBox();
            txt_nombre = new TextBox();
            dgv_resultado = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgv_resultado).BeginInit();
            SuspendLayout();
            // 
            // btn_seleccionar
            // 
            btn_seleccionar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_seleccionar.Location = new Point(816, 465);
            btn_seleccionar.Name = "btn_seleccionar";
            btn_seleccionar.Size = new Size(168, 35);
            btn_seleccionar.TabIndex = 67;
            btn_seleccionar.Text = "Seleccionar";
            btn_seleccionar.UseVisualStyleBackColor = true;
            btn_seleccionar.Click += btn_seleccionar_Click;
            // 
            // txt_busqueda
            // 
            txt_busqueda.Location = new Point(82, 26);
            txt_busqueda.Name = "txt_busqueda";
            txt_busqueda.Size = new Size(249, 23);
            txt_busqueda.TabIndex = 66;
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_buscar.Location = new Point(337, 21);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(98, 35);
            btn_buscar.TabIndex = 65;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(15, 28);
            label4.Name = "label4";
            label4.Size = new Size(61, 21);
            label4.TabIndex = 63;
            label4.Text = "Buscar:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(518, 352);
            label10.Name = "label10";
            label10.Size = new Size(120, 21);
            label10.TabIndex = 59;
            label10.Text = "Teléfono celular:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label9.Location = new Point(518, 308);
            label9.Name = "label9";
            label9.Size = new Size(123, 21);
            label9.TabIndex = 58;
            label9.Text = "Teléfono de casa:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(518, 264);
            label8.Name = "label8";
            label8.Size = new Size(59, 21);
            label8.TabIndex = 57;
            label8.Text = "E-mail:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(518, 220);
            label7.Name = "label7";
            label7.Size = new Size(42, 21);
            label7.TabIndex = 56;
            label7.Text = "RFC:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(518, 176);
            label3.Name = "label3";
            label3.Size = new Size(129, 21);
            label3.TabIndex = 55;
            label3.Text = "Apellido materno:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(518, 132);
            label2.Name = "label2";
            label2.Size = new Size(124, 21);
            label2.TabIndex = 54;
            label2.Text = "Apellido paterno:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(518, 88);
            label1.Name = "label1";
            label1.Size = new Size(88, 21);
            label1.TabIndex = 53;
            label1.Text = "Nombre(s):";
            // 
            // txt_telCel
            // 
            txt_telCel.Location = new Point(693, 354);
            txt_telCel.Name = "txt_telCel";
            txt_telCel.ReadOnly = true;
            txt_telCel.Size = new Size(119, 23);
            txt_telCel.TabIndex = 52;
            // 
            // txt_telCasa
            // 
            txt_telCasa.Location = new Point(693, 310);
            txt_telCasa.Name = "txt_telCasa";
            txt_telCasa.ReadOnly = true;
            txt_telCasa.Size = new Size(119, 23);
            txt_telCasa.TabIndex = 51;
            // 
            // txt_email
            // 
            txt_email.Location = new Point(693, 266);
            txt_email.Name = "txt_email";
            txt_email.ReadOnly = true;
            txt_email.Size = new Size(291, 23);
            txt_email.TabIndex = 50;
            // 
            // txt_rfc
            // 
            txt_rfc.Location = new Point(693, 222);
            txt_rfc.Name = "txt_rfc";
            txt_rfc.ReadOnly = true;
            txt_rfc.Size = new Size(291, 23);
            txt_rfc.TabIndex = 49;
            // 
            // txt_apMat
            // 
            txt_apMat.Location = new Point(693, 178);
            txt_apMat.Name = "txt_apMat";
            txt_apMat.ReadOnly = true;
            txt_apMat.Size = new Size(291, 23);
            txt_apMat.TabIndex = 48;
            // 
            // txt_apPat
            // 
            txt_apPat.Location = new Point(693, 134);
            txt_apPat.Name = "txt_apPat";
            txt_apPat.ReadOnly = true;
            txt_apPat.Size = new Size(291, 23);
            txt_apPat.TabIndex = 47;
            // 
            // txt_nombre
            // 
            txt_nombre.Location = new Point(693, 90);
            txt_nombre.Name = "txt_nombre";
            txt_nombre.ReadOnly = true;
            txt_nombre.Size = new Size(291, 23);
            txt_nombre.TabIndex = 46;
            // 
            // dgv_resultado
            // 
            dgv_resultado.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_resultado.Location = new Point(12, 88);
            dgv_resultado.Name = "dgv_resultado";
            dgv_resultado.Size = new Size(433, 412);
            dgv_resultado.TabIndex = 68;
            dgv_resultado.CellContentClick += dgv_resultado_CellClick;
            // 
            // FormReservasHuesped
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1048, 526);
            Controls.Add(dgv_resultado);
            Controls.Add(btn_seleccionar);
            Controls.Add(txt_busqueda);
            Controls.Add(btn_buscar);
            Controls.Add(label4);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txt_telCel);
            Controls.Add(txt_telCasa);
            Controls.Add(txt_email);
            Controls.Add(txt_rfc);
            Controls.Add(txt_apMat);
            Controls.Add(txt_apPat);
            Controls.Add(txt_nombre);
            Name = "FormReservasHuesped";
            Text = "FormReservasHuesped";
            ((System.ComponentModel.ISupportInitialize)dgv_resultado).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_seleccionar;
        private TextBox txt_busqueda;
        private Button btn_buscar;
        private Label label4;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txt_telCel;
        private TextBox txt_telCasa;
        private TextBox txt_email;
        private TextBox txt_rfc;
        private TextBox txt_apMat;
        private TextBox txt_apPat;
        private TextBox txt_nombre;
        private DataGridView dgv_resultado;
    }
}