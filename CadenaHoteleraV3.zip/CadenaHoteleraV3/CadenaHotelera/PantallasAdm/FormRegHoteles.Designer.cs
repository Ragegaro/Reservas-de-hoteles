﻿namespace CadenaHotelera.PantallasAdm
{
    partial class FormRegHoteles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            checkBox1 = new CheckBox();
            checkedListBox1 = new CheckedListBox();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            textBox6 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label11.Location = new Point(39, 419);
            label11.Name = "label11";
            label11.Size = new Size(140, 21);
            label11.TabIndex = 46;
            label11.Text = "Salones de eventos:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(39, 379);
            label10.Name = "label10";
            label10.Size = new Size(153, 21);
            label10.TabIndex = 45;
            label10.Text = "Cantidad de piscinas:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label9.Location = new Point(670, 53);
            label9.Name = "label9";
            label9.Size = new Size(141, 21);
            label9.TabIndex = 44;
            label9.Text = "Tipos de habitación";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(441, 92);
            label8.Name = "label8";
            label8.Size = new Size(155, 21);
            label8.TabIndex = 43;
            label8.Text = "Servicios adicionales:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(39, 339);
            label7.Name = "label7";
            label7.Size = new Size(109, 21);
            label7.TabIndex = 42;
            label7.Text = "Zona turística:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label6.Location = new Point(39, 219);
            label6.Name = "label6";
            label6.Size = new Size(62, 21);
            label6.TabIndex = 41;
            label6.Text = "Ciudad:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label5.Location = new Point(39, 179);
            label5.Name = "label5";
            label5.Size = new Size(60, 21);
            label5.TabIndex = 40;
            label5.Text = "Estado:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(39, 139);
            label4.Name = "label4";
            label4.Size = new Size(44, 21);
            label4.TabIndex = 39;
            label4.Text = "País:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(39, 299);
            label3.Name = "label3";
            label3.Size = new Size(128, 21);
            label3.TabIndex = 38;
            label3.Text = "Número de pisos:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(39, 259);
            label2.Name = "label2";
            label2.Size = new Size(79, 21);
            label2.TabIndex = 37;
            label2.Text = "Domicilio:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(39, 99);
            label1.Name = "label1";
            label1.Size = new Size(125, 21);
            label1.TabIndex = 36;
            label1.Text = "Nombre de hotel:";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(197, 181);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(145, 23);
            comboBox2.TabIndex = 34;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(197, 141);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(145, 23);
            comboBox1.TabIndex = 33;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(197, 421);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(48, 23);
            textBox8.TabIndex = 32;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(197, 381);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(48, 23);
            textBox7.TabIndex = 31;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(197, 341);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(224, 23);
            textBox5.TabIndex = 29;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(197, 221);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(224, 23);
            textBox4.TabIndex = 28;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(197, 301);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(48, 23);
            textBox3.TabIndex = 27;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(197, 261);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(224, 23);
            textBox2.TabIndex = 26;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(197, 101);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(224, 23);
            textBox1.TabIndex = 25;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            checkBox1.Location = new Point(39, 462);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(124, 25);
            checkBox1.TabIndex = 47;
            checkBox1.Text = "Frente a playa";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkedListBox1
            // 
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Location = new Point(441, 116);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(211, 328);
            checkedListBox1.TabIndex = 48;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label12.Location = new Point(670, 211);
            label12.Name = "label12";
            label12.Size = new Size(183, 21);
            label12.TabIndex = 56;
            label12.Text = "Cantidad de habitaciones:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label13.Location = new Point(670, 91);
            label13.Name = "label13";
            label13.Size = new Size(45, 21);
            label13.TabIndex = 55;
            label13.Text = "Tipo:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label14.Location = new Point(670, 171);
            label14.Name = "label14";
            label14.Size = new Size(96, 21);
            label14.TabIndex = 54;
            label14.Text = "Amenidades:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label15.Location = new Point(670, 131);
            label15.Name = "label15";
            label15.Size = new Size(115, 21);
            label15.TabIndex = 53;
            label15.Text = "Características:";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(828, 173);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(224, 23);
            textBox6.TabIndex = 52;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(828, 93);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(224, 23);
            textBox9.TabIndex = 51;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(871, 213);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(48, 23);
            textBox10.TabIndex = 50;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(828, 133);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(224, 23);
            textBox11.TabIndex = 49;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(671, 258);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(386, 298);
            dataGridView1.TabIndex = 57;
            // 
            // FormRegHoteles
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(dataGridView1);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(textBox6);
            Controls.Add(textBox9);
            Controls.Add(textBox10);
            Controls.Add(textBox11);
            Controls.Add(checkedListBox1);
            Controls.Add(checkBox1);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "FormRegHoteles";
            Text = "FormRegHoteles";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private CheckBox checkBox1;
        private CheckedListBox checkedListBox1;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox textBox6;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private DataGridView dataGridView1;
    }
}