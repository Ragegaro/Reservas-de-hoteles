﻿namespace CadenaHotelera.Pantallas
{
    partial class FormRegClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txt_Nombre = new TextBox();
            txt_ApPat = new TextBox();
            txt_ApMat = new TextBox();
            txt_ciudad = new TextBox();
            txt_RFC = new TextBox();
            txt_Email = new TextBox();
            txt_telCas = new TextBox();
            txt_telCel = new TextBox();
            cb_pais = new ComboBox();
            cb_estado = new ComboBox();
            dtp_nacimiento = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            cb_estadoCivil = new ComboBox();
            btn_registrar = new Button();
            dgv_clientes = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgv_clientes).BeginInit();
            SuspendLayout();
            // 
            // txt_Nombre
            // 
            txt_Nombre.Location = new Point(208, 37);
            txt_Nombre.Name = "txt_Nombre";
            txt_Nombre.Size = new Size(224, 23);
            txt_Nombre.TabIndex = 0;
            // 
            // txt_ApPat
            // 
            txt_ApPat.Location = new Point(208, 78);
            txt_ApPat.Name = "txt_ApPat";
            txt_ApPat.Size = new Size(224, 23);
            txt_ApPat.TabIndex = 1;
            // 
            // txt_ApMat
            // 
            txt_ApMat.Location = new Point(208, 119);
            txt_ApMat.Name = "txt_ApMat";
            txt_ApMat.Size = new Size(224, 23);
            txt_ApMat.TabIndex = 2;
            // 
            // txt_ciudad
            // 
            txt_ciudad.Location = new Point(208, 242);
            txt_ciudad.Name = "txt_ciudad";
            txt_ciudad.Size = new Size(224, 23);
            txt_ciudad.TabIndex = 3;
            // 
            // txt_RFC
            // 
            txt_RFC.Location = new Point(208, 288);
            txt_RFC.Name = "txt_RFC";
            txt_RFC.Size = new Size(224, 23);
            txt_RFC.TabIndex = 4;
            // 
            // txt_Email
            // 
            txt_Email.Location = new Point(208, 330);
            txt_Email.Name = "txt_Email";
            txt_Email.Size = new Size(224, 23);
            txt_Email.TabIndex = 5;
            // 
            // txt_telCas
            // 
            txt_telCas.Location = new Point(208, 372);
            txt_telCas.Name = "txt_telCas";
            txt_telCas.Size = new Size(119, 23);
            txt_telCas.TabIndex = 6;
            // 
            // txt_telCel
            // 
            txt_telCel.Location = new Point(208, 414);
            txt_telCel.Name = "txt_telCel";
            txt_telCel.Size = new Size(119, 23);
            txt_telCel.TabIndex = 7;
            // 
            // cb_pais
            // 
            cb_pais.FormattingEnabled = true;
            cb_pais.Location = new Point(208, 160);
            cb_pais.Name = "cb_pais";
            cb_pais.Size = new Size(145, 23);
            cb_pais.TabIndex = 9;
            cb_pais.SelectedIndexChanged += cb_pais_SelectedIndexChanged;
            // 
            // cb_estado
            // 
            cb_estado.FormattingEnabled = true;
            cb_estado.Location = new Point(208, 201);
            cb_estado.Name = "cb_estado";
            cb_estado.Size = new Size(145, 23);
            cb_estado.TabIndex = 10;
            // 
            // dtp_nacimiento
            // 
            dtp_nacimiento.Location = new Point(208, 456);
            dtp_nacimiento.Name = "dtp_nacimiento";
            dtp_nacimiento.Size = new Size(200, 23);
            dtp_nacimiento.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(31, 35);
            label1.Name = "label1";
            label1.Size = new Size(88, 21);
            label1.TabIndex = 12;
            label1.Text = "Nombre(s):";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(31, 76);
            label2.Name = "label2";
            label2.Size = new Size(124, 21);
            label2.TabIndex = 13;
            label2.Text = "Apellido paterno:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(31, 117);
            label3.Name = "label3";
            label3.Size = new Size(129, 21);
            label3.TabIndex = 14;
            label3.Text = "Apellido materno:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(31, 158);
            label4.Name = "label4";
            label4.Size = new Size(44, 21);
            label4.TabIndex = 15;
            label4.Text = "País:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label5.Location = new Point(31, 199);
            label5.Name = "label5";
            label5.Size = new Size(60, 21);
            label5.TabIndex = 16;
            label5.Text = "Estado:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label6.Location = new Point(31, 240);
            label6.Name = "label6";
            label6.Size = new Size(62, 21);
            label6.TabIndex = 17;
            label6.Text = "Ciudad:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(33, 286);
            label7.Name = "label7";
            label7.Size = new Size(42, 21);
            label7.TabIndex = 18;
            label7.Text = "RFC:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(33, 328);
            label8.Name = "label8";
            label8.Size = new Size(59, 21);
            label8.TabIndex = 19;
            label8.Text = "E-mail:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label9.Location = new Point(33, 370);
            label9.Name = "label9";
            label9.Size = new Size(123, 21);
            label9.TabIndex = 20;
            label9.Text = "Teléfono de casa:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(33, 412);
            label10.Name = "label10";
            label10.Size = new Size(120, 21);
            label10.TabIndex = 21;
            label10.Text = "Teléfono celular:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label11.Location = new Point(33, 454);
            label11.Name = "label11";
            label11.Size = new Size(151, 21);
            label11.TabIndex = 22;
            label11.Text = "Fecha de nacimiento:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label12.Location = new Point(33, 496);
            label12.Name = "label12";
            label12.Size = new Size(92, 21);
            label12.TabIndex = 23;
            label12.Text = "Estado civil:";
            // 
            // cb_estadoCivil
            // 
            cb_estadoCivil.FormattingEnabled = true;
            cb_estadoCivil.Location = new Point(208, 498);
            cb_estadoCivil.Name = "cb_estadoCivil";
            cb_estadoCivil.Size = new Size(145, 23);
            cb_estadoCivil.TabIndex = 24;
            // 
            // btn_registrar
            // 
            btn_registrar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_registrar.Location = new Point(934, 484);
            btn_registrar.Name = "btn_registrar";
            btn_registrar.Size = new Size(100, 37);
            btn_registrar.TabIndex = 25;
            btn_registrar.Text = "Registrar";
            btn_registrar.UseVisualStyleBackColor = true;
            btn_registrar.Click += button1_Click;
            // 
            // dgv_clientes
            // 
            dgv_clientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_clientes.Location = new Point(493, 66);
            dgv_clientes.Name = "dgv_clientes";
            dgv_clientes.Size = new Size(541, 367);
            dgv_clientes.TabIndex = 72;
            // 
            // FormRegClientes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(dgv_clientes);
            Controls.Add(btn_registrar);
            Controls.Add(cb_estadoCivil);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dtp_nacimiento);
            Controls.Add(cb_estado);
            Controls.Add(cb_pais);
            Controls.Add(txt_telCel);
            Controls.Add(txt_telCas);
            Controls.Add(txt_Email);
            Controls.Add(txt_RFC);
            Controls.Add(txt_ciudad);
            Controls.Add(txt_ApMat);
            Controls.Add(txt_ApPat);
            Controls.Add(txt_Nombre);
            Name = "FormRegClientes";
            Text = "FormRegClientes";
            ((System.ComponentModel.ISupportInitialize)dgv_clientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_Nombre;
        private TextBox txt_ApPat;
        private TextBox txt_ApMat;
        private TextBox txt_ciudad;
        private TextBox txt_RFC;
        private TextBox txt_Email;
        private TextBox txt_telCas;
        private TextBox txt_telCel;
        private ComboBox cb_pais;
        private ComboBox cb_estado;
        private DateTimePicker dtp_nacimiento;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private ComboBox cb_estadoCivil;
        private Button btn_registrar;
        private DataGridView dgv_clientes;
    }
}