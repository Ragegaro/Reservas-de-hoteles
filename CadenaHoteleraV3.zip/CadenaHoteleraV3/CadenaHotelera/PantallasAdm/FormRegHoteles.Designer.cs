﻿namespace CadenaHotelera.PantallasAdm
{
    partial class FormRegHoteles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            cb_estado = new ComboBox();
            cb_pais = new ComboBox();
            txt_zonaTur = new TextBox();
            txt_ciudad = new TextBox();
            txt_numPisos = new TextBox();
            txt_domicilio = new TextBox();
            txt_nomHotel = new TextBox();
            chlb_servAdi = new CheckedListBox();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            txt_amenidades = new TextBox();
            txt_tipo = new TextBox();
            txt_cantidadHabi = new TextBox();
            txt_caract = new TextBox();
            dgv_habitaciones = new DataGridView();
            btn_registrar = new Button();
            btn_agregarHabitacion = new Button();
            label10 = new Label();
            txt_costo = new TextBox();
            btn_eliminarHabitacion = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_habitaciones).BeginInit();
            SuspendLayout();
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label9.Location = new Point(463, 37);
            label9.Name = "label9";
            label9.Size = new Size(141, 21);
            label9.TabIndex = 44;
            label9.Text = "Tipos de habitación";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(32, 314);
            label8.Name = "label8";
            label8.Size = new Size(155, 21);
            label8.TabIndex = 43;
            label8.Text = "Servicios adicionales:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(32, 273);
            label7.Name = "label7";
            label7.Size = new Size(109, 21);
            label7.TabIndex = 42;
            label7.Text = "Zona turística:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label6.Location = new Point(32, 153);
            label6.Name = "label6";
            label6.Size = new Size(62, 21);
            label6.TabIndex = 41;
            label6.Text = "Ciudad:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label5.Location = new Point(32, 113);
            label5.Name = "label5";
            label5.Size = new Size(60, 21);
            label5.TabIndex = 40;
            label5.Text = "Estado:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(32, 73);
            label4.Name = "label4";
            label4.Size = new Size(44, 21);
            label4.TabIndex = 39;
            label4.Text = "País:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(32, 233);
            label3.Name = "label3";
            label3.Size = new Size(128, 21);
            label3.TabIndex = 38;
            label3.Text = "Número de pisos:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(32, 193);
            label2.Name = "label2";
            label2.Size = new Size(79, 21);
            label2.TabIndex = 37;
            label2.Text = "Domicilio:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(32, 33);
            label1.Name = "label1";
            label1.Size = new Size(125, 21);
            label1.TabIndex = 36;
            label1.Text = "Nombre de hotel:";
            // 
            // cb_estado
            // 
            cb_estado.FormattingEnabled = true;
            cb_estado.Location = new Point(190, 115);
            cb_estado.Name = "cb_estado";
            cb_estado.Size = new Size(145, 23);
            cb_estado.TabIndex = 34;
            // 
            // cb_pais
            // 
            cb_pais.FormattingEnabled = true;
            cb_pais.Location = new Point(190, 75);
            cb_pais.Name = "cb_pais";
            cb_pais.Size = new Size(145, 23);
            cb_pais.TabIndex = 33;
            cb_pais.SelectedIndexChanged += cb_pais_SelectedIndexChanged;
            // 
            // txt_zonaTur
            // 
            txt_zonaTur.Location = new Point(190, 275);
            txt_zonaTur.Name = "txt_zonaTur";
            txt_zonaTur.Size = new Size(224, 23);
            txt_zonaTur.TabIndex = 29;
            // 
            // txt_ciudad
            // 
            txt_ciudad.Location = new Point(190, 155);
            txt_ciudad.Name = "txt_ciudad";
            txt_ciudad.Size = new Size(224, 23);
            txt_ciudad.TabIndex = 28;
            // 
            // txt_numPisos
            // 
            txt_numPisos.Location = new Point(190, 235);
            txt_numPisos.Name = "txt_numPisos";
            txt_numPisos.Size = new Size(48, 23);
            txt_numPisos.TabIndex = 27;
            // 
            // txt_domicilio
            // 
            txt_domicilio.Location = new Point(190, 195);
            txt_domicilio.Name = "txt_domicilio";
            txt_domicilio.Size = new Size(224, 23);
            txt_domicilio.TabIndex = 26;
            // 
            // txt_nomHotel
            // 
            txt_nomHotel.Location = new Point(190, 35);
            txt_nomHotel.Name = "txt_nomHotel";
            txt_nomHotel.Size = new Size(224, 23);
            txt_nomHotel.TabIndex = 25;
            // 
            // chlb_servAdi
            // 
            chlb_servAdi.FormattingEnabled = true;
            chlb_servAdi.Location = new Point(32, 354);
            chlb_servAdi.Name = "chlb_servAdi";
            chlb_servAdi.Size = new Size(382, 202);
            chlb_servAdi.TabIndex = 48;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label12.Location = new Point(463, 195);
            label12.Name = "label12";
            label12.Size = new Size(183, 21);
            label12.TabIndex = 56;
            label12.Text = "Cantidad de habitaciones:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label13.Location = new Point(463, 75);
            label13.Name = "label13";
            label13.Size = new Size(45, 21);
            label13.TabIndex = 55;
            label13.Text = "Tipo:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label14.Location = new Point(463, 155);
            label14.Name = "label14";
            label14.Size = new Size(96, 21);
            label14.TabIndex = 54;
            label14.Text = "Amenidades:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label15.Location = new Point(463, 115);
            label15.Name = "label15";
            label15.Size = new Size(115, 21);
            label15.TabIndex = 53;
            label15.Text = "Características:";
            // 
            // txt_amenidades
            // 
            txt_amenidades.Location = new Point(621, 157);
            txt_amenidades.Name = "txt_amenidades";
            txt_amenidades.Size = new Size(224, 23);
            txt_amenidades.TabIndex = 52;
            // 
            // txt_tipo
            // 
            txt_tipo.Location = new Point(621, 77);
            txt_tipo.Name = "txt_tipo";
            txt_tipo.Size = new Size(224, 23);
            txt_tipo.TabIndex = 51;
            // 
            // txt_cantidadHabi
            // 
            txt_cantidadHabi.Location = new Point(664, 197);
            txt_cantidadHabi.Name = "txt_cantidadHabi";
            txt_cantidadHabi.Size = new Size(72, 23);
            txt_cantidadHabi.TabIndex = 50;
            // 
            // txt_caract
            // 
            txt_caract.Location = new Point(621, 117);
            txt_caract.Name = "txt_caract";
            txt_caract.Size = new Size(224, 23);
            txt_caract.TabIndex = 49;
            // 
            // dgv_habitaciones
            // 
            dgv_habitaciones.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_habitaciones.Location = new Point(464, 334);
            dgv_habitaciones.Name = "dgv_habitaciones";
            dgv_habitaciones.Size = new Size(386, 222);
            dgv_habitaciones.TabIndex = 57;
            // 
            // btn_registrar
            // 
            btn_registrar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_registrar.Location = new Point(908, 521);
            btn_registrar.Name = "btn_registrar";
            btn_registrar.Size = new Size(125, 35);
            btn_registrar.TabIndex = 71;
            btn_registrar.Text = "Registrar";
            btn_registrar.UseVisualStyleBackColor = true;
            btn_registrar.Click += btn_registrar_Click;
            // 
            // btn_agregarHabitacion
            // 
            btn_agregarHabitacion.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_agregarHabitacion.Location = new Point(463, 275);
            btn_agregarHabitacion.Name = "btn_agregarHabitacion";
            btn_agregarHabitacion.Size = new Size(183, 30);
            btn_agregarHabitacion.TabIndex = 72;
            btn_agregarHabitacion.Text = "Agregar habitación";
            btn_agregarHabitacion.UseVisualStyleBackColor = true;
            btn_agregarHabitacion.Click += btn_agregarHabitacion_Click_1;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(463, 237);
            label10.Name = "label10";
            label10.Size = new Size(117, 21);
            label10.TabIndex = 74;
            label10.Text = "Costo por noche";
            // 
            // txt_costo
            // 
            txt_costo.Location = new Point(664, 239);
            txt_costo.Name = "txt_costo";
            txt_costo.Size = new Size(72, 23);
            txt_costo.TabIndex = 73;
            // 
            // btn_eliminarHabitacion
            // 
            btn_eliminarHabitacion.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_eliminarHabitacion.Location = new Point(856, 334);
            btn_eliminarHabitacion.Name = "btn_eliminarHabitacion";
            btn_eliminarHabitacion.Size = new Size(85, 30);
            btn_eliminarHabitacion.TabIndex = 75;
            btn_eliminarHabitacion.Text = "Eliminar";
            btn_eliminarHabitacion.UseVisualStyleBackColor = true;
            btn_eliminarHabitacion.Click += btn_eliminarHabitacion_Click_1;
            // 
            // FormRegHoteles
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(btn_eliminarHabitacion);
            Controls.Add(label10);
            Controls.Add(txt_costo);
            Controls.Add(btn_agregarHabitacion);
            Controls.Add(btn_registrar);
            Controls.Add(dgv_habitaciones);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(txt_amenidades);
            Controls.Add(txt_tipo);
            Controls.Add(txt_cantidadHabi);
            Controls.Add(txt_caract);
            Controls.Add(chlb_servAdi);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cb_estado);
            Controls.Add(cb_pais);
            Controls.Add(txt_zonaTur);
            Controls.Add(txt_ciudad);
            Controls.Add(txt_numPisos);
            Controls.Add(txt_domicilio);
            Controls.Add(txt_nomHotel);
            Name = "FormRegHoteles";
            Text = "FormRegHoteles";
            ((System.ComponentModel.ISupportInitialize)dgv_habitaciones).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox cb_estado;
        private ComboBox cb_pais;
        private TextBox txt_zonaTur;
        private TextBox txt_ciudad;
        private TextBox txt_numPisos;
        private TextBox txt_domicilio;
        private TextBox txt_nomHotel;
        private CheckedListBox chlb_servAdi;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox txt_amenidades;
        private TextBox txt_tipo;
        private TextBox txt_cantidadHabi;
        private TextBox txt_caract;
        private DataGridView dgv_habitaciones;
        private Button btn_registrar;
        private Button btn_agregarHabitacion;
        private Label label10;
        private TextBox txt_costo;
        private Button btn_eliminarHabitacion;
    }
}