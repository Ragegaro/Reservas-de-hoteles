﻿using Cassandra;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasOp.PantallasReservas
{
    public partial class FormReservaListaHoteles : Form
    {
        public FormReservaListaHoteles()
        {
            InitializeComponent();
            FormReservaListaHoteles_Load();
        }



        private void FormReservaListaHoteles_Load()
        {
                        var session = CassandraConnector.Session;

            // Obtener todas las ciudades únicas de hoteles
            var query = "SELECT DISTINCT nombre_hotel FROM  hoteles ALLOW FILTERING";
            var resultado = session.Execute(query);

            cb_ciudad.Items.Clear();
            foreach (var row in resultado)
            {
                cb_ciudad.Items.Add(row.GetValue<string>("ciudad"));
            }
        }

        private void cb_ciudad_SelectedIndexChanged(object sender, EventArgs e)
        {
                        var session = CassandraConnector.Session;
            string ciudad = cb_ciudad.SelectedItem.ToString();

            string query = "SELECT * FROM  hoteles WHERE ciudad = ? ALLOW FILTERING";
            var prepared = session.Prepare(query);
            var result = session.Execute(prepared.Bind(ciudad));

            lbx_listaHoteles.Items.Clear();
            foreach (var row in result)
            {
                string nombre = row.GetValue<string>("nombre_hotel");
                lbx_listaHoteles.Items.Add(nombre);
            }
        }

        private void lbx_listaHoteles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbx_listaHoteles.SelectedItem == null) return;

            var session = CassandraConnector.Session;
            string nombre = lbx_listaHoteles.SelectedItem.ToString();

            string query = "SELECT * FROM hoteles WHERE nombre_hotel = ? ALLOW FILTERING";
            var prepared = session.Prepare(query);
            var row = session.Execute(prepared.Bind(nombre)).FirstOrDefault();

            if (row != null)
            {
                lab_nombre.Text = row.GetValue<string>("nombre_hotel");
                txt_pais.Text = row.GetValue<string>("pais");
                txt_estado.Text = row.GetValue<string>("estado");
                cb_ciudad.Text = row.GetValue<string>("ciudad");
                tb_desc1.Text = row.GetValue<string>("domicilio");
                tb_desc2.Text = row.GetValue<string>("zona_turistica");

                // servicios_adicionales es una lista
                tb_desc3.Text = string.Join(", ", row.GetValue<List<string>>("servicios_adicionales"));
            }
        }

        private void btn_seleccionar_Click(object sender, EventArgs e)
        {
            if (lab_nombre.Text == "")
            {
                MessageBox.Show("Selecciona un hotel.");
                return;
            }

            ReservaTemp.HotelSeleccionado = lab_nombre.Text; // esto es lo correcto
            ReservaTemp.Ciudad = cb_ciudad.Text;
            ReservaTemp.Estado = txt_estado.Text;
            ReservaTemp.Pais = txt_pais.Text;

            MessageBox.Show("Hotel seleccionado correctamente.");
            this.Close();
        }

        private void btn_seleccionar_Click1(object sender, EventArgs e)
        {
            if (lab_nombre.Text == "")
            {
                MessageBox.Show("Selecciona un hotel.");
                return;
            }

            ReservaTemp.HotelSeleccionado = txt_pais.Text;
            ReservaTemp.Ciudad = cb_ciudad.Text;
            ReservaTemp.Estado = txt_estado.Text;
            ReservaTemp.Pais = txt_pais.Text;

            MessageBox.Show("Hotel seleccionado correctamente.");
            this.Close();
        }
    }
}
