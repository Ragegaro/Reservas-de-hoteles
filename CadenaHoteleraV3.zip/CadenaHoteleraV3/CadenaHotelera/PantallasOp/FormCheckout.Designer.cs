﻿namespace CadenaHotelera.PantallasOp
{
    partial class FormCheckout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_Confirmar = new Button();
            label5 = new Label();
            label6 = new Label();
            TB_tipoHabi = new TextBox();
            TB_numHabi = new TextBox();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            TB_telCel = new TextBox();
            TB_telCasa = new TextBox();
            TB_email = new TextBox();
            TB_RFC = new TextBox();
            CB_NumRes = new ComboBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            TB_ApMaterno = new TextBox();
            TB_ApPaterno = new TextBox();
            TB_Nombre = new TextBox();
            SuspendLayout();
            // 
            // btn_Confirmar
            // 
            btn_Confirmar.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            btn_Confirmar.Location = new Point(750, 393);
            btn_Confirmar.Name = "btn_Confirmar";
            btn_Confirmar.Size = new Size(168, 35);
            btn_Confirmar.TabIndex = 69;
            btn_Confirmar.Text = "Confirmar Check-Out";
            btn_Confirmar.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label5.Location = new Point(644, 177);
            label5.Name = "label5";
            label5.Size = new Size(134, 21);
            label5.TabIndex = 68;
            label5.Text = "Tipo de habitación";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label6.Location = new Point(644, 136);
            label6.Name = "label6";
            label6.Size = new Size(164, 21);
            label6.TabIndex = 67;
            label6.Text = "Número de habitación:";
            // 
            // TB_tipoHabi
            // 
            TB_tipoHabi.Location = new Point(817, 179);
            TB_tipoHabi.Name = "TB_tipoHabi";
            TB_tipoHabi.ReadOnly = true;
            TB_tipoHabi.Size = new Size(101, 23);
            TB_tipoHabi.TabIndex = 66;
            // 
            // TB_numHabi
            // 
            TB_numHabi.Location = new Point(817, 138);
            TB_numHabi.Name = "TB_numHabi";
            TB_numHabi.ReadOnly = true;
            TB_numHabi.Size = new Size(101, 23);
            TB_numHabi.TabIndex = 65;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label10.Location = new Point(146, 391);
            label10.Name = "label10";
            label10.Size = new Size(120, 21);
            label10.TabIndex = 64;
            label10.Text = "Teléfono celular:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label9.Location = new Point(146, 349);
            label9.Name = "label9";
            label9.Size = new Size(123, 21);
            label9.TabIndex = 63;
            label9.Text = "Teléfono de casa:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label8.Location = new Point(146, 307);
            label8.Name = "label8";
            label8.Size = new Size(59, 21);
            label8.TabIndex = 62;
            label8.Text = "E-mail:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label7.Location = new Point(146, 265);
            label7.Name = "label7";
            label7.Size = new Size(42, 21);
            label7.TabIndex = 61;
            label7.Text = "RFC:";
            // 
            // TB_telCel
            // 
            TB_telCel.Location = new Point(321, 393);
            TB_telCel.Name = "TB_telCel";
            TB_telCel.ReadOnly = true;
            TB_telCel.Size = new Size(119, 23);
            TB_telCel.TabIndex = 60;
            // 
            // TB_telCasa
            // 
            TB_telCasa.Location = new Point(321, 351);
            TB_telCasa.Name = "TB_telCasa";
            TB_telCasa.ReadOnly = true;
            TB_telCasa.Size = new Size(119, 23);
            TB_telCasa.TabIndex = 59;
            // 
            // TB_email
            // 
            TB_email.Location = new Point(321, 309);
            TB_email.Name = "TB_email";
            TB_email.ReadOnly = true;
            TB_email.Size = new Size(224, 23);
            TB_email.TabIndex = 58;
            // 
            // TB_RFC
            // 
            TB_RFC.Location = new Point(321, 267);
            TB_RFC.Name = "TB_RFC";
            TB_RFC.ReadOnly = true;
            TB_RFC.Size = new Size(224, 23);
            TB_RFC.TabIndex = 57;
            // 
            // CB_NumRes
            // 
            CB_NumRes.FormattingEnabled = true;
            CB_NumRes.Location = new Point(321, 63);
            CB_NumRes.Name = "CB_NumRes";
            CB_NumRes.Size = new Size(224, 23);
            CB_NumRes.TabIndex = 56;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label4.Location = new Point(148, 61);
            label4.Name = "label4";
            label4.Size = new Size(167, 21);
            label4.TabIndex = 55;
            label4.Text = "Número de reservación";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label3.Location = new Point(148, 218);
            label3.Name = "label3";
            label3.Size = new Size(129, 21);
            label3.TabIndex = 54;
            label3.Text = "Apellido materno:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label2.Location = new Point(148, 177);
            label2.Name = "label2";
            label2.Size = new Size(124, 21);
            label2.TabIndex = 53;
            label2.Text = "Apellido paterno:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 11.249999F, FontStyle.Bold);
            label1.Location = new Point(148, 136);
            label1.Name = "label1";
            label1.Size = new Size(88, 21);
            label1.TabIndex = 52;
            label1.Text = "Nombre(s):";
            // 
            // TB_ApMaterno
            // 
            TB_ApMaterno.Location = new Point(321, 220);
            TB_ApMaterno.Name = "TB_ApMaterno";
            TB_ApMaterno.ReadOnly = true;
            TB_ApMaterno.Size = new Size(224, 23);
            TB_ApMaterno.TabIndex = 51;
            // 
            // TB_ApPaterno
            // 
            TB_ApPaterno.Location = new Point(321, 179);
            TB_ApPaterno.Name = "TB_ApPaterno";
            TB_ApPaterno.ReadOnly = true;
            TB_ApPaterno.Size = new Size(224, 23);
            TB_ApPaterno.TabIndex = 50;
            // 
            // TB_Nombre
            // 
            TB_Nombre.Location = new Point(321, 138);
            TB_Nombre.Name = "TB_Nombre";
            TB_Nombre.ReadOnly = true;
            TB_Nombre.Size = new Size(224, 23);
            TB_Nombre.TabIndex = 49;
            // 
            // FormCheckout
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 601);
            Controls.Add(btn_Confirmar);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(TB_tipoHabi);
            Controls.Add(TB_numHabi);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(TB_telCel);
            Controls.Add(TB_telCasa);
            Controls.Add(TB_email);
            Controls.Add(TB_RFC);
            Controls.Add(CB_NumRes);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(TB_ApMaterno);
            Controls.Add(TB_ApPaterno);
            Controls.Add(TB_Nombre);
            Name = "FormCheckout";
            Text = "FormCheckout";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_Confirmar;
        private Label label5;
        private Label label6;
        private TextBox TB_tipoHabi;
        private TextBox TB_numHabi;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private TextBox TB_telCel;
        private TextBox TB_telCasa;
        private TextBox TB_email;
        private TextBox TB_RFC;
        private ComboBox CB_NumRes;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox TB_ApMaterno;
        private TextBox TB_ApPaterno;
        private TextBox TB_Nombre;
    }
}