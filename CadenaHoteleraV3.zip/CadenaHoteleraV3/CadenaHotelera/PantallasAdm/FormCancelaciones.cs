﻿using Cassandra;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadenaHotelera.PantallasAdm
{
    public partial class FormCancelaciones : Form
    {
        public FormCancelaciones()
        {
            InitializeComponent();
        }

        private void FormCancelaciones_Load(object sender, EventArgs e)
        {
                        var session = CassandraConnector.Session;

            string query = "SELECT codigo_reserva, rfc_huesped, nombre_hotel, tipo_cuarto, fecha_entrada, fecha_salida FROM reservaciones WHERE estatus = 'Activa' ALLOW FILTERING";
            var result = session.Execute(query);

            if (dgv_listaRes.Columns.Count == 0)
            {
                dgv_listaRes.ColumnCount = 6;
                dgv_listaRes.Columns[0].Name = "Código";
                dgv_listaRes.Columns[1].Name = "RFC";
                dgv_listaRes.Columns[2].Name = "Hotel";
                dgv_listaRes.Columns[3].Name = "Tipo de cuarto";
                dgv_listaRes.Columns[4].Name = "Fecha entrada";
                dgv_listaRes.Columns[5].Name = "Fecha salida";
            }

            dgv_listaRes.Rows.Clear();

            foreach (var row in result)
            {
                var fechaEntrada = row.GetValue<Cassandra.LocalDate>("fecha_entrada");
                var fechaSalida = row.GetValue<Cassandra.LocalDate>("fecha_salida");

                dgv_listaRes.Rows.Add(
                    row.GetValue<Guid>("codigo_reserva"),
                    row.GetValue<string>("rfc_huesped"),
                    row.GetValue<string>("nombre_hotel"),
                    row.GetValue<string>("tipo_cuarto"),
                    new DateTime(fechaEntrada.Year, fechaEntrada.Month, fechaEntrada.Day).ToShortDateString(),
                    new DateTime(fechaSalida.Year, fechaSalida.Month, fechaSalida.Day).ToShortDateString()
                );
            }
        }

        private void btn_cancelarRes_Click(object sender, EventArgs e)
        {
            if (dgv_listaRes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona una reservación para cancelar.");
                return;
            }

                        var session = CassandraConnector.Session;
            var codigo = (Guid)dgv_listaRes.SelectedRows[0].Cells[0].Value;

            // Obtener la fecha de entrada para validar cancelación
            string selectQuery = "SELECT fecha_entrada FROM  reservaciones WHERE codigo_reserva = ?";
            var fechaResult = session.Execute(session.Prepare(selectQuery).Bind(codigo));
            var localFecha = fechaResult.First().GetValue<Cassandra.LocalDate>("fecha_entrada");
            var fechaEntrada = new DateTime(localFecha.Year, localFecha.Month, localFecha.Day);

            if ((fechaEntrada - DateTime.Today).TotalDays < 3)
            {
                MessageBox.Show("La reservación solo puede cancelarse con mínimo 3 días de anticipación.");
                return;
            }

            string updateQuery = "UPDATE  reservaciones SET estatus = ? WHERE codigo_reserva = ?";
            var updateStatement = session.Prepare(updateQuery).Bind("Cancelada", codigo);
            session.Execute(updateStatement);

            MessageBox.Show("Reservación cancelada correctamente.");
            FormCancelaciones_Load(sender, e); // recargar la tabla
        }
    }
}
